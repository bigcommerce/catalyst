(()=>{var e={};e.id=1141,e.ids=[1141],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10289:(e,t,r)=>{"use strict";r.d(t,{AddressListSection:()=>s});let s=(0,r(62900).registerClientReference)(function(){throw Error("Attempted to call AddressListSection() from the server but AddressListSection is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/jorge.moya/dev/catalyst/core/vibes/soul/sections/address-list-section/index.tsx","AddressListSection")},12300:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>o});var s=r(11248),a=r(33043),i=r(27006),n=r(30042),d=r(86139);async function o({children:e,params:t}){let{locale:r}=await t;(0,a.I)(r);let o=await (0,i.A)("Account.Layout");return(0,s.jsx)(d.c,{sidebar:(0,s.jsx)(n.w,{links:[{href:"/account/orders/",label:o("orders")},{href:"/account/addresses/",label:o("addresses")},{href:"/account/settings/",label:o("settings")},{href:"/account/wishlists/",label:o("wishlists")},{href:"/logout",label:o("logout"),prefetch:"none"}]}),sidebarSize:"small",children:e})}},12349:(e,t,r)=>{"use strict";r.d(t,{$g:()=>n,Kt:()=>a,L7:()=>d,UX:()=>i,aE:()=>o,lQ:()=>l});var s=r(90081),a=function(e){return e[e.email=1]="email",e[e.password=2]="password",e[e.confirmPassword=3]="confirmPassword",e[e.firstName=4]="firstName",e[e.lastName=5]="lastName",e[e.company=6]="company",e[e.phone=7]="phone",e[e.address1=8]="address1",e[e.address2=9]="address2",e[e.city=10]="city",e[e.countryCode=11]="countryCode",e[e.stateOrProvince=12]="stateOrProvince",e[e.postalCode=13]="postalCode",e[e.currentPassword=24]="currentPassword",e[e.exclusiveOffers=25]="exclusiveOffers",e}({});let i=[24],n=[[4,5],1,2,3,6,7,8,9,[10,12],[13,11]],d=[[4,5],6,7,8,9,[10,12],[13,11]],o=e=>{switch(e.__typename){case"CheckboxesFormFieldValue":return{[e.name]:e.valueEntityIds};case"DateFormFieldValue":return{[e.name]:e.date.utc};case"MultipleChoiceFormFieldValue":return{[e.name]:e.valueEntityId};case"NumberFormFieldValue":return{[e.name]:e.number};case"PasswordFormFieldValue":return{[e.name]:e.password};case"TextFormFieldValue":return{[e.name]:e.text};case"MultilineTextFormFieldValue":return{[e.name]:e.multilineText};default:return{}}},l=(e,t)=>{let r=new Map(e.map(e=>[e.entityId,e])),a=t.map(e=>Array.isArray(e)?e.map(e=>r.get(e)).filter(s.t):r.get(e)).filter(s.t),i=new Set(t.flatMap(e=>Array.isArray(e)?e:[e]));return[...a,...e.filter(e=>!i.has(e.entityId))]}},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},28583:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>F,generateMetadata:()=>I});var s=r(11248),a=r(95931),i=r(27006),n=r(33043),d=r(10289),o=r(83888),l=r(12349),c=r(90081),u=r(31655),m=r(31311),p=r(51633),f=r(13051),y=r(13832),g=r(76970),b=r(14315),h=r(72989),x=r(92430);let v=(0,b.U)(`
    query GetCustomerAddressesQuery($after: String, $before: String, $first: Int, $last: Int) {
      customer {
        entityId
        addresses(before: $before, after: $after, first: $first, last: $last) {
          pageInfo {
            ...PaginationFragment
          }
          collectionInfo {
            totalItems
          }
          edges {
            node {
              entityId
              firstName
              lastName
              address1
              address2
              city
              stateOrProvince
              countryCode
              phone
              postalCode
              company
              formFields {
                ...FormFieldValuesFragment
              }
            }
          }
        }
      }
      site {
        settings {
          formFields {
            shippingAddress {
              ...FormFieldsFragment
            }
          }
        }
      }
      geography {
        countries {
          code
          name
        }
      }
    }
  `,[g.p,x.z,x.M]),z=(0,p.cache)(async({before:e="",after:t="",limit:r=10})=>{let s=await (0,f.GG)(),a=await y.S.fetch({document:v,variables:{...e?{last:r,before:e}:{first:r,after:t}},customerAccessToken:s,fetchOptions:{cache:"no-store",next:{tags:[h.g.customer]}}}),i=a.data.customer?.addresses;if(i)return{pageInfo:i.pageInfo,totalAddresses:i.collectionInfo?.totalItems??0,addresses:(0,m.removeEdgesAndNodes)({edges:i.edges}),shippingAddressFields:a.data.site.settings?.formFields.shippingAddress,countries:a.data.geography.countries}});async function I({params:e}){let{locale:t}=await e;return{title:(await (0,i.A)({locale:t,namespace:"Account.Addresses"}))("title")}}async function F({params:e,searchParams:t}){let{locale:r}=await e;(0,n.I)(r);let m=await (0,i.A)("Account.Addresses"),{before:p,after:f}=await t,y=await z({...f&&{after:f},...p&&{before:p}});y||(0,a.notFound)();let{shippingAddressFields:g=[],countries:b}=y,h=y.addresses.map(e=>({id:e.entityId.toString(),firstName:e.firstName,lastName:e.lastName,address1:e.address1,address2:e.address2??void 0,city:e.city,stateOrProvince:e.stateOrProvince??void 0,countryCode:e.countryCode,postalCode:e.postalCode??void 0,phone:e.phone??void 0,company:e.company??void 0,...e.formFields.reduce((e,t)=>({...e,...(0,l.aE)(t)}),{})})),x=(0,l.lQ)(g,l.L7).map(e=>Array.isArray(e)?e.map(o.q).filter(c.t):(0,o.q)(e)).filter(c.t).map(e=>Array.isArray(e)?e.map(e=>(0,o.j)(e,b??[])):(0,o.j)(e,b??[])).filter(c.t);return(0,s.jsx)(d.AddressListSection,{addressAction:u.n,addresses:h,cancelLabel:m("cancel"),createLabel:m("create"),deleteLabel:m("delete"),editLabel:m("edit"),emptyStateTitle:m("EmptyState.title"),fields:[...x,{name:"id",type:"hidden",label:"ID"}],minimumAddressCount:0,setDefaultLabel:m("setDefault"),showAddFormLabel:m("cta"),title:m("title"),updateLabel:m("update")})}},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29727:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page-experimental.runtime.prod.js")},31655:(e,t,r)=>{"use strict";r.d(t,{x:()=>j,n:()=>N});var s=r(33797);r(40211);var a=r(31311),i=r(2124),n=r(30518),d=r(27006),o=r(51094);let l=o.z.object({id:o.z.string(),firstName:o.z.string(),lastName:o.z.string(),company:o.z.string().optional(),address1:o.z.string(),address2:o.z.string().optional(),city:o.z.string(),stateOrProvince:o.z.string().optional(),postalCode:o.z.string().optional(),phone:o.z.string().optional(),countryCode:o.z.string()}).passthrough();var c=r(13051),u=r(13832),m=r(14315),p=r(72989),f=r(12349);let y=(0,m.U)(`
  mutation AddCustomerAddressMutation($input: AddCustomerAddressInput!) {
    customer {
      addCustomerAddress(input: $input) {
        errors {
          ... on CustomerAddressCreationError {
            message
          }
          ... on CustomerNotLoggedInError {
            message
          }
          ... on ValidationError {
            message
            path
          }
        }
        address {
          entityId
        }
      }
    }
  }
`),g=o.z.coerce.string().pipe(o.z.coerce.number()),b=o.z.object({firstName:o.z.string(),lastName:o.z.string(),address1:o.z.string(),address2:o.z.string().optional(),city:o.z.string(),company:o.z.string().optional(),countryCode:o.z.string(),stateOrProvince:o.z.string().optional(),phone:o.z.string().optional(),postalCode:o.z.string().optional(),formFields:o.z.object({checkboxes:o.z.array(o.z.object({fieldEntityId:g,fieldValueEntityIds:o.z.array(g)})),multipleChoices:o.z.array(o.z.object({fieldEntityId:g,fieldValueEntityId:g})),numbers:o.z.array(o.z.object({fieldEntityId:g,number:g})),dates:o.z.array(o.z.object({fieldEntityId:g,date:o.z.string()})),passwords:o.z.array(o.z.object({fieldEntityId:g,password:o.z.string()})),multilineTexts:o.z.array(o.z.object({fieldEntityId:g,multilineText:o.z.string()})),texts:o.z.array(o.z.object({fieldEntityId:g,text:o.z.string()}))})});async function h(e,t){let r=await (0,d.A)("Account.Addresses"),s=await (0,c.GG)(),o=(0,i.L)(t,{schema:l});if("success"!==o.status)return{...e,lastResult:o.reply()};try{let t=function(e,t){let r=t.flatMap(e=>Array.isArray(e)?e:[e]).filter(e=>e.id&&![String(f.Kt.firstName),String(f.Kt.lastName),String(f.Kt.address1),String(f.Kt.address2),String(f.Kt.city),String(f.Kt.company),String(f.Kt.countryCode),String(f.Kt.stateOrProvince),String(f.Kt.phone),String(f.Kt.postalCode)].includes(e.id)),s={firstName:e.firstName,lastName:e.lastName,address1:e.address1,address2:e.address2,city:e.city,company:e.company,countryCode:e.countryCode,stateOrProvince:e.stateOrProvince,phone:e.phone,postalCode:e.postalCode,formFields:{checkboxes:r.filter(e=>["checkbox-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityIds:Array.isArray(e[t.name])?e[t.name]:[e[t.name]]})),multipleChoices:r.filter(e=>["radio-group","button-radio-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityId:e[t.name]})),numbers:r.filter(e=>["number"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,number:e[t.name]})),dates:r.filter(e=>["date"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,date:new Date(String(e[t.name])).toISOString()})),passwords:r.filter(e=>["password"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,password:e[t.name]})),multilineTexts:r.filter(e=>["textarea"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,multilineText:e[t.name]})),texts:r.filter(e=>["text"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,text:e[t.name]}))}};return b.parse(s)}(o.value,e.fields),r=(await u.S.fetch({document:y,customerAccessToken:s,fetchOptions:{cache:"no-store"},variables:{input:t}})).data.customer.addCustomerAddress;if(r.errors.length>0)return{...e,lastResult:o.reply({formErrors:r.errors.map(e=>e.message)})};return(0,n.unstable_expireTag)(p.g.customer),{addresses:[...e.addresses,{...o.value,id:String(r.address?.entityId)}],lastResult:o.reply({resetForm:!0}),defaultAddress:e.defaultAddress,fields:e.fields}}catch(t){if(console.error(t),t instanceof a.BigCommerceGQLError)return{...e,lastResult:o.reply({formErrors:t.errors.map(({message:e})=>e)})};if(t instanceof a.BigCommerceAPIError)return{...e,lastResult:o.reply({formErrors:[t.message]})};return{...e,lastResult:o.reply({formErrors:[r("somethingWentWrong")]})}}}let x=(0,m.U)(`
  mutation DeleteCustomerAddressMutation($input: DeleteCustomerAddressInput!) {
    customer {
      deleteCustomerAddress(input: $input) {
        errors {
          __typename
          ... on CustomerAddressDeletionError {
            message
          }
          ... on CustomerNotLoggedInError {
            message
          }
        }
      }
    }
  }
`),v=o.z.coerce.string().pipe(o.z.coerce.number()),z=o.z.object({addressEntityId:v});async function I(e,t){let r=await (0,d.A)("Account.Addresses"),s=await (0,c.GG)(),o=(0,i.L)(t,{schema:l});if("success"!==o.status)return{...e,lastResult:o.reply()};try{var m;let t=(m=o.value,z.parse({addressEntityId:m.id})),r=(await u.S.fetch({document:x,customerAccessToken:s,fetchOptions:{cache:"no-store"},variables:{input:t}})).data.customer.deleteCustomerAddress;if(r.errors.length>0)return{...e,lastResult:o.reply({formErrors:r.errors.map(e=>e.message)})};return(0,n.unstable_expireTag)(p.g.customer),{addresses:e.addresses.filter(e=>e.id!==String(o.value.id)),lastResult:o.reply({resetForm:!0}),defaultAddress:e.defaultAddress,fields:e.fields}}catch(t){if(console.error(t),t instanceof a.BigCommerceGQLError)return{...e,lastResult:o.reply({formErrors:t.errors.map(({message:e})=>e)})};if(t instanceof Error)return{...e,lastResult:o.reply({formErrors:[t.message]})};return{...e,lastResult:o.reply({formErrors:[r("somethingWentWrong")]})}}}let F=(0,m.U)(`
  mutation UpdateCustomerAddressMutation($input: UpdateCustomerAddressInput!) {
    customer {
      updateCustomerAddress(input: $input) {
        errors {
          __typename
          ... on AddressDoesNotExistError {
            message
          }
          ... on CustomerAddressUpdateError {
            message
          }
          ... on CustomerNotLoggedInError {
            message
          }
          ... on ValidationError {
            message
            path
          }
        }
        address {
          entityId
        }
      }
    }
  }
`),E=o.z.coerce.string().pipe(o.z.coerce.number()),C=o.z.object({addressEntityId:E,data:o.z.object({firstName:o.z.string().optional(),lastName:o.z.string().optional(),address1:o.z.string().optional(),address2:o.z.string().optional(),city:o.z.string().optional(),company:o.z.string().optional(),countryCode:o.z.string().optional(),stateOrProvince:o.z.string().optional(),phone:o.z.string().optional(),postalCode:o.z.string().optional(),formFields:o.z.object({checkboxes:o.z.array(o.z.object({fieldEntityId:E,fieldValueEntityIds:o.z.array(E)})),multipleChoices:o.z.array(o.z.object({fieldEntityId:E,fieldValueEntityId:E})),numbers:o.z.array(o.z.object({fieldEntityId:E,number:E})),dates:o.z.array(o.z.object({fieldEntityId:E,date:o.z.string()})),passwords:o.z.array(o.z.object({fieldEntityId:E,password:o.z.string()})),multilineTexts:o.z.array(o.z.object({fieldEntityId:E,multilineText:o.z.string()})),texts:o.z.array(o.z.object({fieldEntityId:E,text:o.z.string()}))}).optional()})});async function A(e,t){let r=await (0,d.A)("Account.Addresses"),s=await (0,c.GG)(),o=(0,i.L)(t,{schema:l});if("success"!==o.status)return{...e,lastResult:o.reply()};try{let t=function(e,t){let r=t.flatMap(e=>Array.isArray(e)?e:[e]).filter(t=>!!e[t.name]).filter(e=>e.id&&![String(f.Kt.firstName),String(f.Kt.lastName),String(f.Kt.address1),String(f.Kt.address2),String(f.Kt.city),String(f.Kt.company),String(f.Kt.countryCode),String(f.Kt.stateOrProvince),String(f.Kt.phone),String(f.Kt.postalCode)].includes(e.id)),s={addressEntityId:e.id,data:{firstName:e.firstName,lastName:e.lastName,address1:e.address1,address2:e.address2,city:e.city,company:e.company,countryCode:e.countryCode,stateOrProvince:e.stateOrProvince,phone:e.phone,postalCode:e.postalCode,formFields:{checkboxes:r.filter(e=>["checkbox-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityIds:Array.isArray(e[t.name])?e[t.name]:[e[t.name]]})),multipleChoices:r.filter(e=>["radio-group","button-radio-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityId:e[t.name]})),numbers:r.filter(e=>["number"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,number:e[t.name]})),dates:r.filter(e=>["date"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,date:new Date(String(e[t.name])).toISOString()})),passwords:r.filter(e=>["password"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,password:e[t.name]})),multilineTexts:r.filter(e=>["textarea"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,multilineText:e[t.name]})),texts:r.filter(e=>["text"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,text:e[t.name]}))}}};return C.parse(s)}(o.value,e.fields),r=(await u.S.fetch({document:F,customerAccessToken:s,fetchOptions:{cache:"no-store"},variables:{input:t}})).data.customer.updateCustomerAddress;if(r.errors.length>0)return{...e,lastResult:o.reply({formErrors:r.errors.map(e=>e.message)})};return(0,n.unstable_expireTag)(p.g.customer),{addresses:e.addresses.map(e=>e.id===o.value.id?o.value:e),lastResult:o.reply({resetForm:!0}),defaultAddress:e.defaultAddress,fields:e.fields}}catch(t){if(console.error(t),t instanceof a.BigCommerceGQLError)return{...e,lastResult:o.reply({formErrors:t.errors.map(({message:e})=>e)})};if(t instanceof Error)return{...e,lastResult:o.reply({formErrors:[t.message]})};return{...e,lastResult:o.reply({formErrors:[r("somethingWentWrong")]})}}}let j=async function(e,t){switch(t.get("intent")){case"create":return await h(e,t);case"update":return await A(e,t);case"delete":return await I(e,t);default:return e}};var N=(0,s.A)(j,"60af2cae4ffbb3cfaeafdc17b0f186bb35bdce5330",null)},33873:e=>{"use strict";e.exports=require("path")},55511:e=>{"use strict";e.exports=require("crypto")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},72668:(e,t,r)=>{Promise.resolve().then(r.bind(r,10289))},76970:(e,t,r)=>{"use strict";r.d(t,{p:()=>s});let s=(0,r(14315).U)(`
  fragment PaginationFragment on PageInfo {
    hasNextPage
    hasPreviousPage
    startCursor
    endCursor
  }
`)},77598:e=>{"use strict";e.exports=require("node:crypto")},81751:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>n.a,__next_app__:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>l});var s=r(75448),a=r(25831),i=r(40440),n=r.n(i),d=r(53136),o={};for(let e in d)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>d[e]);r.d(t,o);let l={children:["",{children:["[locale]",{children:["(default)",{children:["account",{children:["addresses",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,28583)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/addresses/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,12300)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/layout.tsx"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,92028)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,67446)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,46774)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,59599)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/error.tsx"],"not-found":[()=>Promise.resolve().then(r.bind(r,79037)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/not-found.tsx"]}]},{"not-found":[()=>Promise.resolve().then(r.t.bind(r,41933,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,49520,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,28129,23)),"next/dist/client/components/unauthorized-error"]}]}.children,c=["/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/addresses/page.tsx"],u={require:r,loadChunk:()=>Promise.resolve()},m=new s.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/[locale]/(default)/account/addresses/page",pathname:"/[locale]/account/addresses",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},82396:(e,t,r)=>{Promise.resolve().then(r.bind(r,84361))},83888:(e,t,r)=>{"use strict";r.d(t,{j:()=>i,q:()=>a});var s=r(12349);let a=e=>{let t=e.name??s.Kt[Number(e.entityId)]??e.label;switch(e.__typename){case"CheckboxesFormField":return{id:String(e.entityId),type:"checkbox-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"DateFormField":return{id:String(e.entityId),type:"date",name:t,label:e.label,required:e.isRequired,minDate:e.minDate??void 0,maxDate:e.maxDate??void 0};case"MultilineTextFormField":return{id:String(e.entityId),type:"textarea",name:t,label:e.label,required:e.isRequired};case"NumberFormField":return{id:String(e.entityId),type:"number",name:t,label:e.label,required:e.isRequired};case"PasswordFormField":return{id:String(e.entityId),type:e.entityId===s.Kt.confirmPassword?"confirm-password":"password",name:t,label:e.label,required:e.isRequired};case"PicklistFormField":if(e.entityId===s.Kt.countryCode)return{id:String(e.entityId),type:"select",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};return{id:String(e.entityId),type:"button-radio-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"RadioButtonsFormField":return{id:String(e.entityId),type:"radio-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"PicklistOrTextFormField":case"TextFormField":return{id:String(e.entityId),type:e.entityId===s.Kt.email?"email":"text",name:t,label:e.label,required:e.isRequired};default:return null}},i=(e,t)=>"select"===e.type&&e.id===String(s.Kt.countryCode)?{...e,options:t.map(e=>({label:e.name,value:e.code}))}:e},83955:(e,t,r)=>{"use strict";r.r(t),r.d(t,{"009326ee3cf7182c7b6269fdbd06fae08f5a8be5b3":()=>s.JQ,"00f18cd8f3edfe417e761e6c7a167eca95fbc78a82":()=>a._,"00fa0fe200fea1fd4091c604922a2f98c10ff5e691":()=>s.Cy,"401eaa26aa87d9f036725b79c56518de68f8fdd77c":()=>s.Om,"4027ff2a9ba69ae80d05c70e793f141bd081ac43fb":()=>s.IG,"40810c2ada176e44cfc36ac58dfc838c0fa8338e6c":()=>a.k,"605cffa0d02884f0c79832e05be84d44feb31db33a":()=>i.$,"60af2cae4ffbb3cfaeafdc17b0f186bb35bdce5330":()=>d.x,"7f08b5bad64ff7f096accb2dbd212712f01ebc5eea":()=>n.G,"7ffa7d8d01732763bccc5f6cf120234bca98d73077":()=>n.Z});var s=r(18657),a=r(5557),i=r(24986),n=r(81488),d=r(31655)},84361:(e,t,r)=>{"use strict";r.d(t,{AddressListSection:()=>b});var s=r(3442),a=r(18731),i=r(48913),n=r(57246),d=r(22696),o=r(40153),l=r(66498),c=r(88390),u=r(93947),m=r(69994),p=r(54634);let f=function({size:e="sm",loadingAriaLabel:t}){return(0,s.jsx)("span",{"aria-label":t??"Loading...",className:(0,p.$)("box-border inline-block animate-spin rounded-full border-contrast-100 border-b-primary-shadow",{xs:"h-5 w-5 border-2",sm:"h-6 w-6 border-2",md:"h-10 w-10 border-[3px]",lg:"h-14 w-14 border-4"}[e]),role:"status"})};r(54069);var y=r(85278);let g=y.z.object({id:y.z.string(),firstName:y.z.string(),lastName:y.z.string(),company:y.z.string().optional(),address1:y.z.string(),address2:y.z.string().optional(),city:y.z.string(),stateOrProvince:y.z.string().optional(),postalCode:y.z.string().optional(),phone:y.z.string().optional(),countryCode:y.z.string()}).passthrough();function b({title:e="Addresses",addresses:t,fields:r,minimumAddressCount:n=1,defaultAddress:o,addressAction:l,editLabel:u="Edit",deleteLabel:p="Delete",updateLabel:f="Update",createLabel:y="Create",cancelLabel:b="Cancel",showAddFormLabel:z="Add address",setDefaultLabel:I="Set as default",emptyStateTitle:F="You don't have any addresses"}){let[E,C]=(0,a.useActionState)(l,{addresses:t,defaultAddress:o,lastResult:null,fields:r}),[A,j]=(0,a.useOptimistic)(E,(e,t)=>{let r=t.get("intent"),s=(0,d.L)(t,{schema:g});if("success"!==s.status)return e;switch(r){case"create":{let t=s.value;return{...e,addresses:[...e.addresses,t]}}case"update":return{...e,addresses:e.addresses.map(e=>e.id===s.value.id?s.value:e)};case"delete":return{...e,addresses:e.addresses.filter(e=>e.id!==s.value.id)};case"setDefault":return{...e,defaultAddress:{id:s.value.id}};default:return e}}),[N,w]=(0,a.useState)([]),[S,P]=(0,a.useState)(!1),[k]=(0,i.mN)({lastResult:E.lastResult}),R=0===A.addresses.length;return(0,s.jsxs)("section",{className:"w-full",children:[(0,s.jsx)("header",{className:"mb-4 border-[var(--address-list-section-border,hsl(var(--contrast-100)))] @2xl:min-h-[72px] @2xl:border-b",children:(0,s.jsxs)("div",{className:"mb-4 flex items-center justify-between",children:[(0,s.jsx)(h,{children:e}),!S&&!R&&(0,s.jsx)(m.$,{onClick:()=>P(!0),size:"small",variant:"tertiary",children:z})]})}),(0,s.jsxs)("div",{children:[S&&(0,s.jsx)("div",{className:"border-b border-[var(--address-list-section-border,hsl(var(--contrast-100)))] pb-6 pt-5",children:(0,s.jsx)("div",{className:"w-[480px] space-y-4",children:(0,s.jsx)(c.DynamicForm,{action:(e,t)=>(P(!1),(0,a.startTransition)(()=>{C(t),j(t)}),{fields:A.fields,lastResult:A.lastResult}),buttonSize:"small",cancelLabel:b,fields:A.fields.map(e=>"name"in e&&"id"===e.name?{...e,name:"id",defaultValue:"new"}:e),onCancel:()=>P(!1),submitLabel:y,submitName:"intent",submitValue:"create"})})}),R?(0,s.jsx)("div",{className:"@container",children:(0,s.jsx)("div",{className:"py-20",children:(0,s.jsxs)("header",{className:"mx-auto flex max-w-2xl flex-col items-center gap-5",children:[(0,s.jsx)("h2",{className:"text-center text-lg font-semibold text-[var(--order-list-empty-state-title,hsl(var(--foreground)))]",children:F}),(0,s.jsx)(m.$,{className:"w-fit",onClick:()=>P(!0),children:z})]})})}):A.addresses.map(e=>{let t=A.fields.map(t=>Array.isArray(t)?t.map(t=>({...t,defaultValue:e[t.name]??""})):{...t,defaultValue:e[t.name]??""});return(0,s.jsx)("div",{className:"border-b border-[var(--address-list-section-border,hsl(var(--contrast-100)))] pb-6 pt-5",children:N.includes(e.id)?(0,s.jsx)("div",{className:"w-[480px] space-y-4",children:(0,s.jsx)(c.DynamicForm,{action:(t,r)=>(w(t=>t.filter(t=>t!==e.id)),(0,a.startTransition)(()=>{C(r),j(r)}),{fields:A.fields,lastResult:A.lastResult}),buttonSize:"small",cancelLabel:b,fields:t,onCancel:()=>w(t=>t.filter(t=>t!==e.id)),submitLabel:f,submitName:"intent",submitValue:"update"})}):(0,s.jsxs)("div",{className:"space-y-4",children:[(0,s.jsx)(x,{address:e,isDefault:A.defaultAddress?A.defaultAddress.id===e.id:void 0}),(0,s.jsxs)("div",{className:"flex gap-1",children:[(0,s.jsx)(m.$,{"aria-label":`${u}: ${e.firstName} ${e.lastName}`,onClick:()=>w(t=>[...t,e.id]),size:"small",variant:"tertiary",children:u}),A.addresses.length>n&&(0,s.jsx)(v,{action:C,address:e,"aria-label":`${p}: ${e.firstName} ${e.lastName}`,intent:"delete",onSubmit:e=>{(0,a.startTransition)(()=>{C(e),j(e)})},children:p}),A.defaultAddress&&A.defaultAddress.id!==e.id&&(0,s.jsx)(v,{action:C,address:e,"aria-label":`${I}: ${e.firstName} ${e.lastName}`,intent:"setDefault",onSubmit:e=>{(0,a.startTransition)(()=>{C(e),j(e)})},children:I})]})]})},e.id)})]})]})}function h({children:e}){let{pending:t}=(0,l.useFormStatus)();return(0,s.jsxs)("h1",{className:"hidden font-[family-name:var(--address-list-section-title-font-family,var(--font-family-heading))] text-4xl font-medium leading-none tracking-tight text-[var(--address-list-section-title,hsl(var(--foreground)))] @2xl:block",children:[e,t&&(0,s.jsx)("span",{className:"ml-2",children:(0,s.jsx)(f,{})})]})}function x({address:e,isDefault:t=!1}){return(0,s.jsxs)("div",{className:"flex gap-10 font-[family-name:var(--address-list-section-content-font-family,var(--font-family-body))]",children:[(0,s.jsxs)("div",{className:"text-sm text-[var(--address-list-section-info,hsl(var(--contrast-500)))]",children:[(0,s.jsxs)("p",{className:"font-bold text-[var(--address-list-section-name,hsl(var(--foreground)))]",children:[e.firstName," ",e.lastName]}),(0,s.jsx)("p",{children:e.company}),(0,s.jsx)("p",{children:e.address1}),(0,s.jsx)("p",{children:e.address2}),(0,s.jsxs)("p",{children:[e.city,", ",e.stateOrProvince," ",e.postalCode]}),(0,s.jsx)("p",{className:"mb-3",children:e.countryCode}),(0,s.jsx)("p",{children:e.phone})]}),(0,s.jsx)("div",{children:t&&(0,s.jsx)(u.E,{children:"Default"})})]})}function v({address:e,intent:t,action:r,onSubmit:l,...c}){let[u,p]=(0,i.mN)({defaultValue:e,constraint:(0,o.z)(g),onValidate:({formData:e})=>(0,d.L)(e,{schema:g}),onSubmit(e,{submission:t,formData:r}){e.preventDefault(),t?.status==="success"&&l(r)}});return(0,s.jsxs)("form",{...(0,n.NE)(u),action:r,children:[(0,a.createElement)("input",{...(0,n.ti)(p.id,{type:"hidden"}),key:p.id.id}),(0,a.createElement)("input",{...(0,n.ti)(p.firstName,{type:"hidden"}),key:p.firstName.id}),(0,a.createElement)("input",{...(0,n.ti)(p.lastName,{type:"hidden"}),key:p.lastName.id}),(0,a.createElement)("input",{...(0,n.ti)(p.company,{type:"hidden"}),key:p.company.id}),(0,a.createElement)("input",{...(0,n.ti)(p.phone,{type:"hidden"}),key:p.phone.id}),(0,a.createElement)("input",{...(0,n.ti)(p.address1,{type:"hidden"}),key:p.address1.id}),(0,a.createElement)("input",{...(0,n.ti)(p.address2,{type:"hidden"}),key:p.address2.id}),(0,a.createElement)("input",{...(0,n.ti)(p.city,{type:"hidden"}),key:p.city.id}),(0,a.createElement)("input",{...(0,n.ti)(p.stateOrProvince,{type:"hidden"}),key:p.stateOrProvince.id}),(0,a.createElement)("input",{...(0,n.ti)(p.postalCode,{type:"hidden"}),key:p.postalCode.id}),(0,a.createElement)("input",{...(0,n.ti)(p.countryCode,{type:"hidden"}),key:p.countryCode.id}),(0,s.jsx)(m.$,{...c,name:"intent",size:"small",type:"submit",value:t,variant:"tertiary"})]})}},90081:(e,t,r)=>{"use strict";function s(e){return null!=e}r.d(t,{t:()=>s})},92430:(e,t,r)=>{"use strict";r.d(t,{M:()=>a,z:()=>i});var s=r(14315);let a=(0,s.U)(`
  fragment FormFieldsFragment on FormField {
    entityId
    label
    sortOrder
    isBuiltIn
    isRequired
    __typename
    ... on CheckboxesFormField {
      options {
        entityId
        label
      }
    }
    ... on DateFormField {
      defaultDate
      minDate
      maxDate
    }
    ... on MultilineTextFormField {
      defaultText
      rows
    }
    ... on NumberFormField {
      defaultNumber
      maxLength
      minNumber
      maxNumber
    }
    ... on PasswordFormField {
      defaultText
      maxLength
    }
    ... on PicklistFormField {
      choosePrefix
      options {
        entityId
        label
      }
    }
    ... on RadioButtonsFormField {
      options {
        entityId
        label
      }
    }
    ... on TextFormField {
      defaultText
      maxLength
    }
  }
`),i=(0,s.U)(`
  fragment FormFieldValuesFragment on CustomerFormFieldValue {
    entityId
    __typename
    name
    ... on CheckboxesFormFieldValue {
      valueEntityIds
      values
    }
    ... on DateFormFieldValue {
      date {
        utc
      }
    }
    ... on MultipleChoiceFormFieldValue {
      valueEntityId
      value
    }
    ... on NumberFormFieldValue {
      number
    }
    ... on PasswordFormFieldValue {
      password
    }
    ... on TextFormFieldValue {
      text
    }
    ... on MultilineTextFormFieldValue {
      multilineText
    }
  }
`)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[1407,8485,3615,2375,4269,6955,524,7559,295,5444,7708,5223,7985,651,6043,1931,9630,789,7060,8390],()=>r(81751));module.exports=s})();