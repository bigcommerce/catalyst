(()=>{var e={};e.id=9697,e.ids=[9697],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},8520:(e,r,a)=>{"use strict";a.r(r),a.d(r,{GlobalError:()=>l.a,__next_app__:()=>m,pages:()=>c,routeModule:()=>u,tree:()=>d});var t=a(75448),s=a(25831),n=a(40440),l=a.n(n),o=a(53136),i={};for(let e in o)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(i[e]=()=>o[e]);a.d(r,i);let d={children:["",{children:["[locale]",{children:["(default)",{children:["webpages",{children:["[id]",{children:["normal",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,33811)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/webpages/[id]/normal/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,83183)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/webpages/[id]/layout.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,92028)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/layout.tsx"],error:[()=>Promise.resolve().then(a.bind(a,67446)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,46774)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/layout.tsx"],error:[()=>Promise.resolve().then(a.bind(a,59599)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/error.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,79037)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/not-found.tsx"]}]},{"not-found":[()=>Promise.resolve().then(a.t.bind(a,41933,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,49520,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,28129,23)),"next/dist/client/components/unauthorized-error"]}]}.children,c=["/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/webpages/[id]/normal/page.tsx"],m={require:a,loadChunk:()=>Promise.resolve()},u=new t.AppPageRouteModule({definition:{kind:s.RouteKind.APP_PAGE,page:"/[locale]/(default)/webpages/[id]/normal/page",pathname:"/[locale]/webpages/[id]/normal",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},14e3:(e,r,a)=>{"use strict";a.d(r,{E:()=>n});var t=a(11248),s=a(22584);function n({className:e,children:r}){return(0,t.jsx)("span",{className:(0,s.$)("origin-left font-[family-name:var(--animated-underline-font-family,var(--font-family-body))] font-semibold leading-normal text-[var(--animated-underline-text,hsl(var(--foreground)))] transition-[background-size] duration-300 [background:linear-gradient(0deg,var(--animated-underline-hover,hsl(var(--primary))),var(--animated-underline-hover,hsl(var(--primary))))_no-repeat_left_bottom_/_0_2px] hover:bg-[size:100%_2px] group-focus/underline:bg-[size:100%_2px]",e),children:r})}},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29727:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page-experimental.runtime.prod.js")},31017:(e,r,a)=>{"use strict";a.d(r,{A:()=>i});var t=a(51633);let s=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((e,r,a)=>!!e&&""!==e.trim()&&a.indexOf(e)===r).join(" ").trim();var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let o=(0,t.forwardRef)(({color:e="currentColor",size:r=24,strokeWidth:a=2,absoluteStrokeWidth:s,className:o="",children:i,iconNode:d,...c},m)=>(0,t.createElement)("svg",{ref:m,...l,width:r,height:r,stroke:e,strokeWidth:s?24*Number(a)/Number(r):a,className:n("lucide",o),...c},[...d.map(([e,r])=>(0,t.createElement)(e,r)),...Array.isArray(i)?i:[i]])),i=(e,r)=>{let a=(0,t.forwardRef)(({className:a,...l},i)=>(0,t.createElement)(o,{ref:i,iconNode:r,className:n(`lucide-${s(e)}`,a),...l}));return a.displayName=`${e}`,a}},32772:(e,r,a)=>{"use strict";a.d(r,{h:()=>n,i:()=>s});var t=a(31311);let s=e=>(0,t.removeEdgesAndNodes)(e).reduce((e,r)=>r.path?[...e,{label:r.name,href:r.path,id:r.path}]:e,[]);function n(e,r){if(e.length<r)return e;let a=Math.floor(e.length/2),t=e.length-r,s=Math.ceil(t/2),n=Math.floor(t/2),[l,o]=[e.slice(0,a-s),e.slice(a+n)];return o[0]={label:"...",href:"#"},[...l,...o]}},33811:(e,r,a)=>{"use strict";a.r(r),a.d(r,{default:()=>y,generateMetadata:()=>v});var t=a(11248),s=a(95931),n=a(27006),l=a(33043),o=a(51633),i=a(8310),d=a(32772),c=a(98377),m=a(13832),u=a(14315),h=a(99257),x=a(72062);let f=(0,u.U)(`
    query NormalPageQuery($id: ID!) {
      node(id: $id) {
        ... on NormalPage {
          __typename
          name
          ...BreadcrumbsFragment
          htmlBody
          entityId
          seo {
            pageTitle
            metaDescription
            metaKeywords
          }
        }
      }
    }
  `,[x.a]),b=(0,o.cache)(async e=>{let{data:r}=await m.S.fetch({document:f,variables:e,fetchOptions:{next:{revalidate:h.Y}}});return r}),p=(0,o.cache)(async e=>{let r=await b({id:decodeURIComponent(e)}),a=r.node?.__typename==="NormalPage"?r.node:null;if(!a)return(0,s.notFound)();let t=(0,d.i)(a.breadcrumbs);return{title:a.name,breadcrumbs:t,content:a.htmlBody,seo:a.seo}});async function g(e){let r=await (0,n.A)("WebPages.Normal"),a=await p(e),[,...t]=a.breadcrumbs.reverse(),s=[{label:r("home"),href:"/"},...t.reverse(),{label:a.title,href:"#"}];return(0,d.h)(s,5)}async function v({params:e}){let{id:r}=await e,a=await p(r),{pageTitle:t,metaDescription:s,metaKeywords:n}=a.seo;return{title:t||a.title,description:s,keywords:n?n.split(","):null}}async function y({params:e}){let{locale:r,id:a}=await e;return(0,l.I)(r),(0,t.jsx)(c.d,{breadcrumbs:i.RE.from(()=>g(a)),webPage:i.RE.from(()=>p(a))})}},33873:e=>{"use strict";e.exports=require("path")},42882:(e,r,a)=>{"use strict";a.d(r,{A:()=>t});let t=(0,a(31017).A)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},55020:(e,r,a)=>{"use strict";a.d(r,{BI:()=>c,wk:()=>m});var t=a(11248),s=a(22584),n=a(42882),l=a(8310),o=a(14e3),i=a(21345),d=a(64570);function c({breadcrumbs:e,className:r}){return(0,t.jsx)(l.Z6,{fallback:(0,t.jsx)(m,{className:r}),value:e,children:e=>0===e.length?(0,t.jsx)(u,{className:r}):(0,t.jsx)("nav",{"aria-label":"breadcrumb",className:(0,s.$)(r),children:(0,t.jsx)("ol",{className:"flex flex-wrap items-center gap-x-1.5 text-sm @xl:text-base",children:e.map(({label:r,href:a},s)=>s<e.length-1?(0,t.jsxs)("li",{className:"inline-flex items-center gap-x-1.5",children:[(0,t.jsx)(d.Link,{className:"group/underline focus:outline-none",href:a,children:(0,t.jsx)(o.E,{className:"font-[family-name:var(--breadcrumbs-font-family,var(--font-family-body))] text-[var(--breadcrumbs-primary-text,hsl(var(--foreground)))] [background:linear-gradient(0deg,var(--breadcrumbs-hover,hsl(var(--primary))),var(--breadcrumbs-hover,hsl(var(--primary))))_no-repeat_left_bottom_/_0_2px]",children:r})}),(0,t.jsx)(n.A,{"aria-hidden":"true",className:"text-[var(--breadcrumbs-icon,hsl(var(--contrast-500)))]",size:20,strokeWidth:1})]},s):(0,t.jsx)("li",{className:"inline-flex items-center font-[family-name:var(--breadcrumbs-font-family,var(--font-family-body))] text-[var(--breadcrumbs-secondary-text,hsl(var(--contrast-500)))]",children:(0,t.jsx)("span",{"aria-current":"page","aria-disabled":"true",role:"link",children:r})},s))})})})}function m({className:e}){return(0,t.jsx)(i.bL,{className:(0,s.$)("group-has-[[data-pending]]/breadcrumbs:animate-pulse",e),pending:!0,children:(0,t.jsxs)("div",{className:"flex flex-wrap items-center gap-x-1.5 text-sm @xl:text-base",children:[(0,t.jsx)(i.EY,{characterCount:4,className:"rounded text-lg"}),(0,t.jsx)(i.In,{icon:(0,t.jsx)(n.A,{"aria-hidden":!0,className:"h-5 w-5",strokeWidth:1})}),(0,t.jsx)(i.EY,{characterCount:6,className:"rounded text-lg"}),(0,t.jsx)(i.In,{icon:(0,t.jsx)(n.A,{"aria-hidden":!0,className:"h-5 w-5",strokeWidth:1})}),(0,t.jsx)(i.EY,{characterCount:6,className:"rounded text-lg"})]})})}function u({className:e}){return(0,t.jsx)(i.bL,{className:e,children:(0,t.jsx)("div",{className:(0,s.$)("min-h-[1lh]",e)})})}},55511:e=>{"use strict";e.exports=require("crypto")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},67248:(e,r,a)=>{Promise.resolve().then(a.bind(a,64570))},72062:(e,r,a)=>{"use strict";a.d(r,{R:()=>s,a:()=>n});var t=a(14315);let s=(0,t.U)(`
  fragment BreadcrumbsFragment on Category {
    breadcrumbs(depth: 5) {
      edges {
        node {
          name
          path
          entityId
        }
      }
    }
  }
`),n=(0,t.U)(`
  fragment BreadcrumbsFragment on WebPage {
    breadcrumbs(depth: 8) {
      edges {
        node {
          name
          path
        }
      }
    }
  }
`)},76976:(e,r,a)=>{Promise.resolve().then(a.bind(a,6820))},77598:e=>{"use strict";e.exports=require("node:crypto")},83183:(e,r,a)=>{"use strict";a.r(r),a.d(r,{default:()=>x});var t=a(11248),s=a(31311),n=a(33043),l=a(51633),o=a(30042),i=a(86139),d=a(13832),c=a(14315),m=a(99257);let u=(0,c.U)(`
  query WebPageChildrenQuery($id: ID!) {
    node(id: $id) {
      ... on WebPage {
        children(first: 20) {
          edges {
            node {
              name
              ... on NormalPage {
                path
              }
              ... on ContactPage {
                path
              }
              ... on RawHtmlPage {
                path
              }
              ... on ExternalLinkPage {
                link
              }
            }
          }
        }
      }
    }
  }
`),h=(0,l.cache)(async e=>{let{data:r}=await d.S.fetch({document:u,variables:{id:decodeURIComponent(e)},fetchOptions:{next:{revalidate:m.Y}}});if(!r.node||!("children"in r.node))return[];let{children:a}=r.node;return(0,s.removeEdgesAndNodes)(a).reduce((e,r)=>"path"in r?[...e,{label:r.name,href:r.path}]:"link"in r?[...e,{label:r.name,href:r.link}]:e,[])});async function x({params:e,children:r}){let{locale:a,id:s}=await e;return(0,n.I)(a),(0,t.jsx)(i.c,{sidebar:(0,t.jsx)(o.w,{links:h(s)}),sidebarSize:"small",children:r})}},98377:(e,r,a)=>{"use strict";a.d(r,{d:()=>l});var t=a(11248),s=a(8310),n=a(55020);function l({webPage:e,breadcrumbs:r,children:a}){return(0,t.jsx)("section",{className:"w-full max-w-4xl",children:(0,t.jsx)(s.Z6,{fallback:(0,t.jsx)(d,{}),value:e,children:e=>{let{title:s,content:l}=e;return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("header",{className:"pb-8 @2xl:pb-12 @4xl:pb-16",children:[r&&(0,t.jsx)(n.BI,{breadcrumbs:r}),(0,t.jsx)("h1",{className:"mb-4 mt-8 font-heading text-4xl font-medium leading-none @xl:text-5xl @4xl:text-6xl",children:s})]}),(0,t.jsx)("div",{className:"@-xl:[&_h2]:text-4xl prose space-y-4 [&_h2]:font-heading [&_h2]:text-3xl [&_h2]:font-normal [&_h2]:leading-none [&_img]:mx-auto [&_img]:max-h-[600px] [&_img]:w-fit [&_img]:rounded-2xl [&_img]:object-cover",dangerouslySetInnerHTML:{__html:l}}),a]})}})})}function o(){return(0,t.jsx)("div",{className:"mb-4 mt-8 animate-pulse",children:(0,t.jsx)("div",{className:"h-9 w-5/6 rounded-lg bg-contrast-100 @xl:h-12 @4xl:h-[3.75rem]"})})}function i(){return(0,t.jsxs)("div",{className:"mx-auto w-full max-w-4xl animate-pulse pb-8 @2xl:pb-12 @4xl:pb-16",children:[(0,t.jsx)("div",{className:"mb-8 h-[1lh] w-3/5 rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-full rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-full rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-full rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-full rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-full rounded-lg bg-contrast-100"}),(0,t.jsx)("div",{className:"mb-4 h-[0.5lh] w-3/4 rounded-lg bg-contrast-100"})]})}function d(){return(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"mx-auto w-full max-w-4xl pb-8 @2xl:pb-12 @4xl:pb-16",children:[(0,t.jsx)(n.wk,{}),(0,t.jsx)(o,{})]}),(0,t.jsx)(i,{})]})}},98438:(e,r,a)=>{"use strict";a.r(r),a.d(r,{"009326ee3cf7182c7b6269fdbd06fae08f5a8be5b3":()=>t.JQ,"00f18cd8f3edfe417e761e6c7a167eca95fbc78a82":()=>s._,"00fa0fe200fea1fd4091c604922a2f98c10ff5e691":()=>t.Cy,"401eaa26aa87d9f036725b79c56518de68f8fdd77c":()=>t.Om,"4027ff2a9ba69ae80d05c70e793f141bd081ac43fb":()=>t.IG,"40810c2ada176e44cfc36ac58dfc838c0fa8338e6c":()=>s.k,"605cffa0d02884f0c79832e05be84d44feb31db33a":()=>n.$,"7f08b5bad64ff7f096accb2dbd212712f01ebc5eea":()=>l.G,"7ffa7d8d01732763bccc5f6cf120234bca98d73077":()=>l.Z});var t=a(18657),s=a(5557),n=a(24986),l=a(81488)}};var r=require("../../../../../../webpack-runtime.js");r.C(e);var a=e=>r(r.s=e),t=r.X(0,[1407,8485,3615,2375,4269,6955,524,7559,295,5444,7708,6043,1931,9630,789],()=>a(8520));module.exports=t})();