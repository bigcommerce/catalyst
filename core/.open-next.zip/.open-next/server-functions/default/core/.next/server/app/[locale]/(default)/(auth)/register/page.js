(()=>{var e={};e.id=5582,e.ids=[5582],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},12349:(e,t,r)=>{"use strict";r.d(t,{$g:()=>n,Kt:()=>s,L7:()=>l,UX:()=>i,aE:()=>o,lQ:()=>d});var a=r(90081),s=function(e){return e[e.email=1]="email",e[e.password=2]="password",e[e.confirmPassword=3]="confirmPassword",e[e.firstName=4]="firstName",e[e.lastName=5]="lastName",e[e.company=6]="company",e[e.phone=7]="phone",e[e.address1=8]="address1",e[e.address2=9]="address2",e[e.city=10]="city",e[e.countryCode=11]="countryCode",e[e.stateOrProvince=12]="stateOrProvince",e[e.postalCode=13]="postalCode",e[e.currentPassword=24]="currentPassword",e[e.exclusiveOffers=25]="exclusiveOffers",e}({});let i=[24],n=[[4,5],1,2,3,6,7,8,9,[10,12],[13,11]],l=[[4,5],6,7,8,9,[10,12],[13,11]],o=e=>{switch(e.__typename){case"CheckboxesFormFieldValue":return{[e.name]:e.valueEntityIds};case"DateFormFieldValue":return{[e.name]:e.date.utc};case"MultipleChoiceFormFieldValue":return{[e.name]:e.valueEntityId};case"NumberFormFieldValue":return{[e.name]:e.number};case"PasswordFormFieldValue":return{[e.name]:e.password};case"TextFormFieldValue":return{[e.name]:e.text};case"MultilineTextFormFieldValue":return{[e.name]:e.multilineText};default:return{}}},d=(e,t)=>{let r=new Map(e.map(e=>[e.entityId,e])),s=t.map(e=>Array.isArray(e)?e.map(e=>r.get(e)).filter(a.t):r.get(e)).filter(a.t),i=new Set(t.flatMap(e=>Array.isArray(e)?e:[e]));return[...s,...e.filter(e=>!i.has(e.entityId))]}},12802:(e,t,r)=>{Promise.resolve().then(r.bind(r,88390)),Promise.resolve().then(r.bind(r,41154))},13601:(e,t,r)=>{"use strict";r.r(t),r.d(t,{"009326ee3cf7182c7b6269fdbd06fae08f5a8be5b3":()=>a.JQ,"00f18cd8f3edfe417e761e6c7a167eca95fbc78a82":()=>s._,"00fa0fe200fea1fd4091c604922a2f98c10ff5e691":()=>a.Cy,"401eaa26aa87d9f036725b79c56518de68f8fdd77c":()=>a.Om,"4027ff2a9ba69ae80d05c70e793f141bd081ac43fb":()=>a.IG,"40810c2ada176e44cfc36ac58dfc838c0fa8338e6c":()=>s.k,"605cffa0d02884f0c79832e05be84d44feb31db33a":()=>i.$,"60ec24aaa2331c4164fee001e78c09e0e598c896d0":()=>l.S,"7f08b5bad64ff7f096accb2dbd212712f01ebc5eea":()=>n.G,"7ffa7d8d01732763bccc5f6cf120234bca98d73077":()=>n.Z});var a=r(18657),s=r(5557),i=r(24986),n=r(81488),l=r(98897)},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},22068:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>i});var a=r(13051),s=r(24623);async function i({children:e,params:t}){let r=await (0,a.M3)(),{locale:i}=await t;return r&&(0,s.V2)({href:"/account/orders",locale:i}),e}},23042:(e,t,r)=>{Promise.resolve().then(r.bind(r,42400)),Promise.resolve().then(r.bind(r,6820)),Promise.resolve().then(r.bind(r,70806)),Promise.resolve().then(r.bind(r,41154))},26817:(e,t,r)=>{Promise.resolve().then(r.bind(r,41154))},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29727:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page-experimental.runtime.prod.js")},33873:e=>{"use strict";e.exports=require("path")},43381:(e,t,r)=>{"use strict";r.d(t,{g:()=>s,i:()=>a});let a="customAddress_",s="customCustomer_"},43748:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>j,generateMetadata:()=>z});var a=r(11248),s=r(95931),i=r(27006),n=r(33043),l=r(22584),o=r(78606),d=r(96950);function c({className:e,title:t,subtitle:r,fields:s,submitLabel:i,action:n}){return(0,a.jsxs)(d.o,{className:(0,l.$)("mx-auto w-full max-w-4xl",e),containerSize:"lg",children:[null!=t&&""!==t&&(0,a.jsxs)("header",{className:"pb-8 @2xl:pb-12 @4xl:pb-16",children:[(0,a.jsx)("h1",{className:"mb-5 font-heading text-4xl font-medium leading-none @xl:text-5xl",children:t}),null!=r&&""!==r&&(0,a.jsx)("p",{className:"mb-10 text-base font-light leading-none @xl:text-lg",children:r})]}),(0,a.jsx)(o.DynamicForm,{action:n,fields:s,submitLabel:i})]})}var u=r(83888),m=r(12349),p=r(90081),f=r(43381),g=r(98897),h=r(51633),y=r(13051),b=r(13832),x=r(14315),v=r(92430),F=r(10628);let w=async e=>{let t=(await (0,F.b3)()).get("X-Vercel-Protection-Bypass"),r=(await (0,F.b3)()).get("X-Vercel-Set-Bypass-Cookie");if(!(t&&"true"===r))return e},I=(0,x.U)(`
    query RegisterCustomerQuery(
      $customerFilters: FormFieldFiltersInput
      $customerSortBy: FormFieldSortInput
      $addressFilters: FormFieldFiltersInput
      $addressSortBy: FormFieldSortInput
    ) {
      site {
        settings {
          formFields {
            customer(filters: $customerFilters, sortBy: $customerSortBy) {
              ...FormFieldsFragment
            }
            shippingAddress(filters: $addressFilters, sortBy: $addressSortBy) {
              ...FormFieldsFragment
            }
          }
        }
        settings {
          reCaptcha {
            isEnabledOnStorefront
            siteKey
          }
        }
      }
      geography {
        countries {
          code
          name
        }
      }
    }
  `,[v.M]),k=(0,h.cache)(async({address:e,customer:t})=>{let r=await (0,y.GG)(),a=await b.S.fetch({document:I,variables:{addressFilters:e?.filters,addressSortBy:e?.sortBy,customerFilters:t?.filters,customerSortBy:t?.sortBy},fetchOptions:{cache:"no-store"},customerAccessToken:r}),s=a.data.site.settings?.formFields.shippingAddress,i=a.data.site.settings?.formFields.customer,n=a.data.geography.countries,l=await w(a.data.site.settings?.reCaptcha);return s&&i?{addressFields:s,customerFields:i,reCaptchaSettings:l,countries:n}:null});async function z({params:e}){let{locale:t}=await e;return{title:(await (0,i.A)({locale:t,namespace:"Auth.Register"}))("title")}}async function j({params:e}){let{locale:t}=await e;(0,n.I)(t);let r=await (0,i.A)("Auth.Register"),l=await k({address:{sortBy:"SORT_ORDER"},customer:{sortBy:"SORT_ORDER"}});l||(0,s.notFound)();let{addressFields:o,customerFields:d,countries:h}=l,y=(0,m.lQ)([...o.map(e=>e.isBuiltIn?e:{...e,name:`${f.i}${e.label}`}),...d.map(e=>e.isBuiltIn?e:{...e,name:`${f.g}${e.label}`})].filter(e=>!m.UX.includes(e.entityId)),m.$g).map(e=>Array.isArray(e)?e.map(u.q).filter(p.t):(0,u.q)(e)).filter(p.t).map(e=>Array.isArray(e)?e.map(e=>(0,u.j)(e,h??[])):(0,u.j)(e,h??[])).filter(p.t);return(0,a.jsx)(c,{action:g.S,fields:y,submitLabel:r("cta"),title:r("heading")})}},55511:e=>{"use strict";e.exports=require("crypto")},57975:e=>{"use strict";e.exports=require("node:util")},59572:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});var a=r(3442),s=r(56058),i=r(12550);function n({reset:e}){let t=(0,s.c3)("Error");return(0,a.jsx)(i.$,{ctaAction:e,ctaLabel:t("cta"),subtitle:t("subtitle"),title:t("title")})}},62863:(e,t,r)=>{"use strict";r.d(t,{w:()=>i});var a=r(51094);function s(e){let t;switch(e.type){case"number":t=a.z.number(),null!=e.min&&(t=t.min(e.min)),null!=e.max&&(t=t.max(e.max)),!0!==e.required&&(t=t.optional());break;case"password":t=a.z.string().min(8,{message:"Be at least 8 characters long"}).regex(/[a-zA-Z]/,{message:"Contain at least one letter."}).regex(/[0-9]/,{message:"Contain at least one number."}).regex(/[^a-zA-Z0-9]/,{message:"Contain at least one special character."}).trim(),!0!==e.required&&(t=t.optional());break;case"email":t=a.z.string().email({message:"Please enter a valid email."}).trim(),!0!==e.required&&(t=t.optional());break;case"checkbox-group":t=a.z.string().array(),!0===e.required&&(t=t.nonempty());break;default:t=a.z.string(),!0!==e.required&&(t=t.optional())}return t}function i(e){let t,r,i={};return e.forEach(e=>{Array.isArray(e)?e.forEach(e=>{i[e.name]=s(e),"password"===e.type&&(t=e.name),"confirm-password"===e.type&&(r=e.name)}):(i[e.name]=s(e),"password"===e.type&&(t=e.name),"confirm-password"===e.type&&(r=e.name))}),a.z.object(i).superRefine((e,a)=>{null!=t&&null!=r&&e[t]!==e[r]&&a.addIssue({code:"custom",message:"The passwords did not match",path:[r]})})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},67446:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>a});let a=(0,r(62900).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx","default")},72634:(e,t,r)=>{Promise.resolve().then(r.bind(r,78606)),Promise.resolve().then(r.bind(r,25672))},73695:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>n.a,__next_app__:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>d});var a=r(75448),s=r(25831),i=r(40440),n=r.n(i),l=r(53136),o={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>l[e]);r.d(t,o);let d={children:["",{children:["[locale]",{children:["(default)",{children:["(auth)",{children:["register",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,43748)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/(auth)/register/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,22068)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/(auth)/layout.tsx"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,92028)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,67446)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,46774)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,59599)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/error.tsx"],"not-found":[()=>Promise.resolve().then(r.bind(r,79037)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/not-found.tsx"]}]},{"not-found":[()=>Promise.resolve().then(r.t.bind(r,41933,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,49520,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,28129,23)),"next/dist/client/components/unauthorized-error"]}]}.children,c=["/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/(auth)/register/page.tsx"],u={require:r,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:s.RouteKind.APP_PAGE,page:"/[locale]/(default)/(auth)/register/page",pathname:"/[locale]/register",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},77598:e=>{"use strict";e.exports=require("node:crypto")},78360:(e,t,r)=>{Promise.resolve().then(r.bind(r,67446))},78606:(e,t,r)=>{"use strict";r.d(t,{DynamicForm:()=>a});let a=(0,r(62900).registerClientReference)(function(){throw Error("Attempted to call DynamicForm() from the server but DynamicForm is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/jorge.moya/dev/catalyst/core/vibes/soul/form/dynamic-form/index.tsx","DynamicForm")},82874:(e,t,r)=>{Promise.resolve().then(r.bind(r,90065)),Promise.resolve().then(r.bind(r,64570)),Promise.resolve().then(r.bind(r,86695)),Promise.resolve().then(r.bind(r,25672))},83888:(e,t,r)=>{"use strict";r.d(t,{j:()=>i,q:()=>s});var a=r(12349);let s=e=>{let t=e.name??a.Kt[Number(e.entityId)]??e.label;switch(e.__typename){case"CheckboxesFormField":return{id:String(e.entityId),type:"checkbox-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"DateFormField":return{id:String(e.entityId),type:"date",name:t,label:e.label,required:e.isRequired,minDate:e.minDate??void 0,maxDate:e.maxDate??void 0};case"MultilineTextFormField":return{id:String(e.entityId),type:"textarea",name:t,label:e.label,required:e.isRequired};case"NumberFormField":return{id:String(e.entityId),type:"number",name:t,label:e.label,required:e.isRequired};case"PasswordFormField":return{id:String(e.entityId),type:e.entityId===a.Kt.confirmPassword?"confirm-password":"password",name:t,label:e.label,required:e.isRequired};case"PicklistFormField":if(e.entityId===a.Kt.countryCode)return{id:String(e.entityId),type:"select",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};return{id:String(e.entityId),type:"button-radio-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"RadioButtonsFormField":return{id:String(e.entityId),type:"radio-group",name:t,label:e.label,required:e.isRequired,options:e.options.map(e=>({label:e.label,value:String(e.entityId)}))};case"PicklistOrTextFormField":case"TextFormField":return{id:String(e.entityId),type:e.entityId===a.Kt.email?"email":"text",name:t,label:e.label,required:e.isRequired};default:return null}},i=(e,t)=>"select"===e.type&&e.id===String(a.Kt.countryCode)?{...e,options:t.map(e=>({label:e.name,value:e.code}))}:e},85126:(e,t,r)=>{"use strict";r.d(t,{l:()=>o});var a=r(3442),s=r(97362),i=r(54634),n=r(1212),l=r(82169);function o({value:e,name:t,id:r,required:o=!1,pending:d=!1,colorScheme:c="light",disabled:u,label:m,placeholder:p="Select an item",variant:f="rectangle",position:g="popper",side:h="bottom",sideOffset:y=6,onFocus:b,onBlur:x,onOptionMouseEnter:v,onValueChange:F,errors:w,options:I}){return(0,a.jsxs)(s.bL,{disabled:u,name:t,onValueChange:F,required:o,value:e,children:[(0,a.jsxs)(s.l9,{"aria-label":m,className:(0,i.$)("flex h-fit w-full select-none items-center justify-between gap-3 border p-2 px-5 py-3 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2","rectangle"===f?"rounded-lg":"rounded-full",{light:"bg-[var(--select-light-trigger-background,hsl(var(--white)))] text-[var(--select-light-trigger-text,hsl(var(--foreground)))] hover:border-[var(--select-light-trigger-border-hover,hsl(var(--contrast-300)))] hover:bg-[var(--select-light-trigger-background-hover,hsl(var(--contrast-100)))] focus-visible:ring-[var(--select-light-trigger-focus,hsl(var(--primary)))]",dark:"bg-[var(--select-dark-trigger-background,hsl(var(--black)))] text-[var(--select-dark-trigger-text,hsl(var(--background)))] hover:border-[var(--select-dark-trigger-border-hover,hsl(var(--contrast-300)))] hover:bg-[var(--select-dark-trigger-background-hover,hsl(var(--contrast-500)))] focus-visible:ring-[var(--select-dark-trigger-focus,hsl(var(--primary)))]"}[c],{light:w&&w.length>0?"border-[var(--select-light-trigger-border-error,hsl(var(--error)))]":"border-[var(--select-light-trigger-border,hsl(var(--contrast-100)))]",dark:w&&w.length>0?"border-[var(--select-dark-trigger-border-error,hsl(var(--error)))]":"border-[var(--select-dark-trigger-border,hsl(var(--contrast-500)))]"}[c]),"data-pending":!!d||null,id:r,onBlur:x,onFocus:b,children:[(0,a.jsx)(s.WT,{placeholder:p}),(0,a.jsx)(s.In,{asChild:!0,children:(0,a.jsx)(n.A,{className:(0,i.$)("w-5 transition-transform",{light:"text-[var(--select-light-icon,hsl(var(--foreground)))]",dark:"text-[var(--select-dark-icon,hsl(var(--background)))]"}[c]),strokeWidth:1.5})})]}),(0,a.jsx)(s.ZL,{children:(0,a.jsxs)(s.UC,{className:(0,i.$)("z-50 max-h-80 overflow-y-auto rounded-xl p-2 shadow-xl ring-1 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 @4xl:rounded-3xl @4xl:p-4",{popper:"w-[var(--radix-select-trigger-width)]","item-aligned":"w-full"}[g],{light:"bg-[var(--select-light-content-background,hsl(var(--background)))] ring-[var(--select-light-content-border,hsl(var(--contrast-100)))]",dark:"bg-[var(--select-dark-content-background,hsl(var(--foreground)))] ring-[var(--select-dark-content-border,hsl(var(--contrast-500)))]"}[c]),position:g,side:h,sideOffset:y,children:[(0,a.jsx)(s.PP,{className:"flex w-full cursor-default items-center justify-center py-3",children:(0,a.jsx)(l.A,{className:(0,i.$)("w-5",{light:"text-[var(--select-light-icon,hsl(var(--foreground)))]",dark:"text-[var(--select-dark-icon,hsl(var(--background)))]"}[c]),strokeWidth:1.5})}),(0,a.jsx)(s.LM,{children:I.map(e=>(0,a.jsx)(s.q7,{className:(0,i.$)("w-full cursor-default select-none rounded-xl px-3 py-2 text-sm font-medium outline-none transition-colors @4xl:text-base",{light:"text-[var(--select-light-item-text,hsl(var(--contrast-400)))] hover:bg-[var(--select-light-item-background-hover,hsl(var(--contrast-100)))] hover:text-[var(--select-light-item-text-hover,hsl(var(--foreground)))] focus-visible:bg-[var(--select-light-item-background-focus,hsl(var(--contrast-100)))] focus-visible:text-[var(--select-light-item-text-focus,hsl(var(--foreground)))] data-[state=checked]:text-[var(--select-light-item-checked-text-focus,hsl(var(--foreground)))]",dark:"text-[var(--select-dark-item-text,hsl(var(--contrast-200)))] hover:bg-[var(--select-dark-item-background-hover,hsl(var(--contrast-500)))] hover:text-[var(--select-dark-item-text-hover,hsl(var(--background)))] focus-visible:bg-[var(--select-dark-item-background-focus,hsl(var(--contrast-500)))] focus-visible:text-[var(--select-dark-item-text-focus,hsl(var(--background)))] data-[state=checked]:text-[var(--select-dark-item-checked-text-focus,hsl(var(--background)))]"}[c]),onMouseEnter:()=>{v?.(e.value)},value:e.value,children:(0,a.jsx)(s.p4,{children:e.label})},e.value))}),(0,a.jsx)(s.wn,{className:"flex w-full cursor-default items-center justify-center py-3",children:(0,a.jsx)(n.A,{className:(0,i.$)("w-5",{light:"text-[var(--select-icon,hsl(var(--foreground)))]",dark:"text-[var(--select-icon,hsl(var(--background)))]"}[c]),strokeWidth:1.5})})]})})]})}},88088:(e,t,r)=>{Promise.resolve().then(r.bind(r,59572))},90081:(e,t,r)=>{"use strict";function a(e){return null!=e}r.d(t,{t:()=>a})},90369:(e,t,r)=>{Promise.resolve().then(r.bind(r,25672))},92028:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>l,experimental_ppr:()=>o});var a=r(11248),s=r(33043),i=r(49925),n=r(60969);async function l({params:e,children:t}){let{locale:r}=await e;return(0,s.I)(r),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(n.Y,{}),(0,a.jsx)("main",{children:t}),(0,a.jsx)(i.w,{})]})}let o=!0},92430:(e,t,r)=>{"use strict";r.d(t,{M:()=>s,z:()=>i});var a=r(14315);let s=(0,a.U)(`
  fragment FormFieldsFragment on FormField {
    entityId
    label
    sortOrder
    isBuiltIn
    isRequired
    __typename
    ... on CheckboxesFormField {
      options {
        entityId
        label
      }
    }
    ... on DateFormField {
      defaultDate
      minDate
      maxDate
    }
    ... on MultilineTextFormField {
      defaultText
      rows
    }
    ... on NumberFormField {
      defaultNumber
      maxLength
      minNumber
      maxNumber
    }
    ... on PasswordFormField {
      defaultText
      maxLength
    }
    ... on PicklistFormField {
      choosePrefix
      options {
        entityId
        label
      }
    }
    ... on RadioButtonsFormField {
      options {
        entityId
        label
      }
    }
    ... on TextFormField {
      defaultText
      maxLength
    }
  }
`),i=(0,a.U)(`
  fragment FormFieldValuesFragment on CustomerFormFieldValue {
    entityId
    __typename
    name
    ... on CheckboxesFormFieldValue {
      valueEntityIds
      values
    }
    ... on DateFormFieldValue {
      date {
        utc
      }
    }
    ... on MultipleChoiceFormFieldValue {
      valueEntityId
      value
    }
    ... on NumberFormFieldValue {
      number
    }
    ... on PasswordFormFieldValue {
      password
    }
    ... on TextFormFieldValue {
      text
    }
    ... on MultilineTextFormFieldValue {
      multilineText
    }
  }
`)},96950:(e,t,r)=>{"use strict";r.d(t,{o:()=>i});var a=r(11248),s=r(22584);function i({className:e,children:t,containerSize:r="2xl"}){return(0,a.jsx)("section",{className:(0,s.$)("overflow-hidden @container",e),children:(0,a.jsx)("div",{className:(0,s.$)("mx-auto px-4 py-10 @xl:px-6 @xl:py-14 @4xl:px-8 @4xl:py-20",{md:"max-w-[var(--section-max-width-md,768px)]",lg:"max-w-[var(--section-max-width-lg,1024px)]",xl:"max-w-[var(--section-max-width-xl,1280px)]","2xl":"max-w-[var(--section-max-width-2xl,1536px)]",full:"max-w-none"}[r]),children:t})})}},98897:(e,t,r)=>{"use strict";r.d(t,{S:()=>F});var a=r(33797);r(40211);var s=r(31311),i=r(2124),n=r(27006),l=r(89952),o=r(51094),d=r(62863),c=r(13051),u=r(13832),m=r(14315),p=r(12349),f=r(24623),g=r(18657),h=r(43381),y=r(91179);let b=(0,m.U)(`
  mutation RegisterCustomerMutation(
    $input: RegisterCustomerInput!
    $reCaptchaV2: ReCaptchaV2Input
  ) {
    customer {
      registerCustomer(input: $input, reCaptchaV2: $reCaptchaV2) {
        customer {
          firstName
          lastName
        }
        errors {
          ... on EmailAlreadyInUseError {
            message
          }
          ... on AccountCreationDisabledError {
            message
          }
          ... on CustomerRegistrationError {
            message
          }
          ... on ValidationError {
            message
          }
        }
      }
    }
  }
`),x=o.z.string().pipe(o.z.coerce.number()),v=o.z.object({firstName:o.z.string(),lastName:o.z.string(),email:o.z.string(),password:o.z.string(),phone:o.z.string().optional(),company:o.z.string().optional(),address:o.z.object({firstName:o.z.string(),lastName:o.z.string(),address1:o.z.string(),address2:o.z.string().optional(),city:o.z.string(),company:o.z.string().optional(),countryCode:o.z.string(),stateOrProvince:o.z.string().optional(),phone:o.z.string().optional(),postalCode:o.z.string().optional(),formFields:o.z.object({checkboxes:o.z.array(o.z.object({fieldEntityId:x,fieldValueEntityIds:o.z.array(x)})),multipleChoices:o.z.array(o.z.object({fieldEntityId:x,fieldValueEntityId:x})),numbers:o.z.array(o.z.object({fieldEntityId:x,number:x})),dates:o.z.array(o.z.object({fieldEntityId:x,date:o.z.string()})),passwords:o.z.array(o.z.object({fieldEntityId:x,password:o.z.string()})),multilineTexts:o.z.array(o.z.object({fieldEntityId:x,multilineText:o.z.string()})),texts:o.z.array(o.z.object({fieldEntityId:x,text:o.z.string()}))})}).optional(),formFields:o.z.object({checkboxes:o.z.array(o.z.object({fieldEntityId:x,fieldValueEntityIds:o.z.array(x)})),multipleChoices:o.z.array(o.z.object({fieldEntityId:x,fieldValueEntityId:x})),numbers:o.z.array(o.z.object({fieldEntityId:x,number:x})),dates:o.z.array(o.z.object({fieldEntityId:x,date:o.z.string()})),passwords:o.z.array(o.z.object({fieldEntityId:x,password:o.z.string()})),multilineTexts:o.z.array(o.z.object({fieldEntityId:x,multilineText:o.z.string()})),texts:o.z.array(o.z.object({fieldEntityId:x,text:o.z.string()}))})});async function F(e,t){let r=await (0,n.A)("Auth.Register"),a=await (0,l.A)(),o=await (0,g.Cy)(),m=(0,i.L)(t,{schema:(0,d.w)(e.fields)});if("success"!==m.status)return{lastResult:m.reply(),fields:e.fields};try{let t=function(e,t){let r=t.flatMap(e=>Array.isArray(e)?e:[e]).filter(e=>![String(p.Kt.email),String(p.Kt.password),String(p.Kt.confirmPassword),String(p.Kt.firstName),String(p.Kt.lastName),String(p.Kt.address1),String(p.Kt.address2),String(p.Kt.city),String(p.Kt.company),String(p.Kt.countryCode),String(p.Kt.stateOrProvince),String(p.Kt.phone),String(p.Kt.postalCode)].includes(e.name)),a=r.filter(e=>e.name.startsWith(h.i)),s=r.filter(e=>e.name.startsWith(h.g)),i={firstName:e.firstName,lastName:e.lastName,email:e.email,password:e.password,phone:e.phone,company:e.company,address:{firstName:e.firstName,lastName:e.lastName,address1:e.address1,address2:e.address2,city:e.city,company:e.company,countryCode:e.countryCode,stateOrProvince:e.stateOrProvince,phone:e.phone,postalCode:e.postalCode,formFields:{checkboxes:a.filter(e=>["checkbox-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityIds:Array.isArray(e[t.name])?e[t.name]:[e[t.name]]})),multipleChoices:a.filter(e=>["radio-group","button-radio-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityId:e[t.name]})),numbers:a.filter(e=>["number"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,number:e[t.name]})),dates:a.filter(e=>["date"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,date:new Date(String(e[t.name])).toISOString()})),passwords:a.filter(e=>["password"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,password:e[t.name]})),multilineTexts:a.filter(e=>["textarea"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,multilineText:e[t.name]})),texts:a.filter(e=>["text"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,text:e[t.name]}))}},formFields:{checkboxes:s.filter(e=>["checkbox-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityIds:Array.isArray(e[t.name])?e[t.name]:[e[t.name]]})),multipleChoices:s.filter(e=>["radio-group","button-radio-group"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,fieldValueEntityId:e[t.name]})),numbers:s.filter(e=>["number"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,number:e[t.name]})),dates:s.filter(e=>["date"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,date:new Date(String(e[t.name])).toISOString()})),passwords:s.filter(e=>["password"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,password:e[t.name]})),multilineTexts:s.filter(e=>["textarea"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,multilineText:e[t.name]})),texts:s.filter(e=>["text"].includes(e.type)).filter(t=>!!e[t.name]).map(t=>({fieldEntityId:t.id,text:e[t.name]}))}};return v.parse(i)}(m.value,e.fields),r=await u.S.fetch({document:b,variables:{input:t},fetchOptions:{cache:"no-store"}});if(r.data.customer.registerCustomer.errors.length>0)return{lastResult:m.reply({formErrors:r.data.customer.registerCustomer.errors.map(e=>e.message)}),fields:e.fields};await (0,c.Jv)("password",{email:t.email,password:t.password,cartId:o,redirect:!1})}catch(t){if(console.error(t),t instanceof s.BigCommerceGQLError)return{lastResult:m.reply({formErrors:t.errors.map(({message:e})=>e)}),fields:e.fields};if(t instanceof Error)return{lastResult:m.reply({formErrors:[t.message]}),fields:e.fields};return{lastResult:m.reply({formErrors:[r("somethingWentWrong")]}),fields:e.fields}}return(0,f.V2)({href:"/account/orders",locale:a})}(0,y.D)([F]),(0,a.A)(F,"60ec24aaa2331c4164fee001e78c09e0e598c896d0",null)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[1407,8485,3615,2375,4269,6955,524,7559,295,5444,7708,5223,7985,651,6043,1931,9630,7060,8390],()=>r(73695));module.exports=a})();