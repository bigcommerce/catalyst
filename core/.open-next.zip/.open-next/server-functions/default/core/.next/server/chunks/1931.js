"use strict";exports.id=1931,exports.ids=[1931],exports.modules={5557:(t,e,a)=>{a.d(e,{_:()=>i,k:()=>c});var r=a(33797);a(40211);var n=a(10628),s=a(31176);async function i(){let t=await (0,n.UL)(),e=t.get("currencyCode")?.value;if(!e)return;let a=s.K.safeParse(e);return a.success?a.data:void 0}async function c(t){(await (0,n.UL)()).set("currencyCode",t,{httpOnly:!0,secure:!0,sameSite:"lax",path:"/"})}(0,a(91179).D)([i,c]),(0,r.A)(i,"00f18cd8f3edfe417e761e6c7a167eca95fbc78a82",null),(0,r.A)(c,"40810c2ada176e44cfc36ac58dfc838c0fa8338e6c",null)},13051:(t,e,a)=>{a.d(e,{j2:()=>L,Gg:()=>w,GG:()=>G,Y9:()=>O,M3:()=>N,Jv:()=>z,CI:()=>j,LY:()=>y,qO:()=>x});var r=a(7359),n=a(9582),s=a(44322),i=a(96430),c=a(27006),o=a(51094),u=a(10628);let l="authjs.anonymous-session-token",d=async()=>"https"===(await (0,u.b3)()).get("x-forwarded-proto"),m=async(t={cartId:null})=>{let e=process.env.AUTH_SECRET??process.env.NEXTAUTH_SECRET,a=await d()?"__Secure-":"";if(!e)throw Error("AUTH_SECRET is not set");let r=await (0,u.UL)(),n=await (0,s.lF)({salt:`${a}${l}`,secret:e,token:{user:t}});r.set(`${a}${l}`,n,{secure:!0,sameSite:"lax",maxAge:25200,httpOnly:!0})},w=async()=>{let t=await (0,u.UL)(),e=await d()?"__Secure-":"",a=t.get(`${e}${l}`);if(!a)return null;let r=process.env.AUTH_SECRET??process.env.NEXTAUTH_SECRET;if(!r)throw Error("AUTH_SECRET is not set");return await (0,s.D4)({secret:r,salt:`${e}${l}`,token:a.value})},f=async()=>{let t=await (0,u.UL)(),e=await d();t.delete({name:`${e?"__Secure-":""}${l}`,secure:!0,sameSite:"lax",httpOnly:!0})},y=async t=>{if(!await w())return null;await m(t)};var p=a(13832),g=a(14315),I=a(18657),v=a(50551);let h=(0,g.U)(`
  mutation LoginMutation($email: String!, $password: String!, $cartEntityId: String) {
    login(email: $email, password: $password, guestCartEntityId: $cartEntityId) {
      customerAccessToken {
        value
      }
      customer {
        entityId
        firstName
        lastName
        email
      }
      cart {
        entityId
      }
    }
  }
`),C=(0,g.U)(`
  mutation LoginWithCustomerLoginJwtMutation($jwt: String!, $cartEntityId: String) {
    loginWithCustomerLoginJwt(jwt: $jwt, guestCartEntityId: $cartEntityId) {
      customerAccessToken {
        value
      }
      customer {
        entityId
        firstName
        lastName
        email
      }
      cart {
        entityId
      }
    }
  }
`),A=(0,g.U)(`
  mutation LogoutMutation($cartEntityId: String) {
    logout(cartEntityId: $cartEntityId) {
      result
      cartUnassignResult {
        cart {
          entityId
        }
      }
    }
  }
`),T=o.z.string().uuid().or(o.z.literal("undefined")).optional().transform(t=>"undefined"===t?void 0:t),b=o.z.object({email:o.z.string().email(),password:o.z.string().min(1),cartId:T}),S=o.z.object({jwt:o.z.string(),cartId:T}),E=o.z.object({user:o.z.object({cartId:T})});async function $(t,e){let a=await (0,c.A)("Cart");void 0===t&&void 0!==e&&await v.H.info(a("cartRestored"),{position:"top-center"}),e&&t&&e!==t&&await v.H.info(a("cartCombined"),{position:"top-center"}),e&&await (0,I.Om)(e)}async function k(t){let{email:e,password:a,cartId:r}=b.parse(t),n=await p.S.fetch({document:h,variables:{email:e,password:a,cartEntityId:r},fetchOptions:{cache:"no-store"}});if(n.errors&&n.errors.length>0)return null;let s=n.data.login;return s.customer&&s.customerAccessToken?(await $(r,s.cart?.entityId),await f(),{name:`${s.customer.firstName} ${s.customer.lastName}`,email:s.customer.email,customerAccessToken:s.customerAccessToken.value,cartId:s.cart?.entityId}):null}async function U(t){let{jwt:e,cartId:a}=S.parse(t),n=(0,r.i)(e),s=n.channel_id?.toString()??process.env.BIGCOMMERCE_CHANNEL_ID,i=n.impersonator_id?.toString()??null,c=await p.S.fetch({document:C,variables:{jwt:e,cartEntityId:a},channelId:s,fetchOptions:{cache:"no-store"}});if(c.errors&&c.errors.length>0)return null;let o=c.data.loginWithCustomerLoginJwt;return o.customer&&o.customerAccessToken?(await $(a,o.cart?.entityId),await f(),{name:`${o.customer.firstName} ${o.customer.lastName}`,email:o.customer.email,customerAccessToken:o.customerAccessToken.value,impersonatorId:i,cartId:o.cart?.entityId}):null}let _={skipCSRFCheck:void 0,trustHost:"true"===process.env.AUTH_TRUST_HOST||void 0,session:{strategy:"jwt"},pages:{signIn:"/login",signOut:"/logout"},callbacks:{jwt:({token:t,user:e,session:a,trigger:r})=>{if(e?.customerAccessToken&&(t.user={...t.user,customerAccessToken:e.customerAccessToken}),e?.cartId&&(t.user={...t.user,cartId:e.cartId}),"update"===r){let e=E.safeParse(a);e.success&&(t.user={...t.user,cartId:e.data.user.cartId})}return t},session:({session:t,token:e})=>(e.user?.customerAccessToken&&(t.user.customerAccessToken=e.user.customerAccessToken),e.user?.cartId!==void 0&&(t.user.cartId=e.user.cartId),t)},events:{async signOut(t){let e="token"in t?t.token?.user?.cartId:null,a="token"in t?t.token?.user?.customerAccessToken:null;if(a)try{let t=await p.S.fetch({document:A,variables:{cartEntityId:e},customerAccessToken:a,fetchOptions:{cache:"no-store"}});if(await m(),t.data.logout.cartUnassignResult.cart)return void await (0,I.Om)(t.data.logout.cartUnassignResult.cart.entityId);await (0,I.JQ)()}catch(t){console.error(t)}}},providers:[(0,i.A)({id:"password",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"},cartId:{type:"text"}},authorize:k}),(0,i.A)({id:"jwt",credentials:{jwt:{type:"text"},cartId:{type:"text"}},authorize:U})]},{handlers:O,auth:L,signIn:z,signOut:j,unstable_update:x}=(0,n.Ay)(_),G=async()=>{try{let t=await L();return t?.user?.customerAccessToken}catch{}},N=async()=>!!await G()},14315:(t,e,a)=>{a.d(e,{B:()=>r.Bk,U:()=>n});var r=a(52375);let n=(0,r.Se)()},18657:(t,e,a)=>{a.d(e,{IG:()=>h,JQ:()=>v,Cy:()=>g,Om:()=>I});var r=a(33797);a(40211);var n=a(30518),s=a(13051),i=a(72989),c=a(13832),o=a(14315);let u=(0,o.U)(`
  mutation AddCartLineItemMutation($input: AddCartLineItemsInput!) {
    cart {
      addCartLineItems(input: $input) {
        cart {
          entityId
        }
      }
    }
  }
`),l=async(t,e)=>{let a=await (0,s.GG)();return await c.S.fetch({document:u,variables:{input:{cartEntityId:t,data:e}},customerAccessToken:a,fetchOptions:{cache:"no-store"}})};var d=a(5557);let m=(0,o.U)(`
  mutation CreateCartMutation($createCartInput: CreateCartInput!) {
    cart {
      createCart(input: $createCartInput) {
        cart {
          entityId
        }
      }
    }
  }
`),w=async t=>{let e=await (0,s.GG)(),a=await (0,d._)();return await c.S.fetch({document:m,variables:{createCartInput:{...t,currencyCode:a}},customerAccessToken:e,fetchOptions:{cache:"no-store"}})},f=(0,o.U)(`
  query ValidateCartQuery($cartId: String) {
    site {
      cart(entityId: $cartId) {
        entityId
      }
    }
  }
`);async function y(t){let e=await (0,s.GG)();return(await c.S.fetch({document:f,variables:{cartId:t},customerAccessToken:e,fetchOptions:{cache:"no-store",next:{tags:[i.g.cart]}}})).data.site.cart}var p=a(28533);async function g(){let t=await (0,s.Gg)();if(t)return t.user?.cartId??void 0;let e=await (0,s.j2)();return e?.user?.cartId??void 0}async function I(t){if(await (0,s.Gg)())return void await (0,s.LY)({cartId:t});await (0,s.qO)({user:{cartId:t}})}async function v(){if(await (0,s.Gg)())return void await (0,s.LY)({cartId:null});await (0,s.qO)({user:{cartId:null}})}async function h(t){let e=await g(),a=await y(e);if(a){let e=await l(a.entityId,t);if(!e.data.cart.addCartLineItems?.cart?.entityId)throw new p.t;(0,n.unstable_expireTag)(i.g.cart);return}let r=await w(t);if(!r.data.cart.createCart?.cart?.entityId)throw new p.t;await I(r.data.cart.createCart.cart.entityId),(0,n.unstable_expireTag)(i.g.cart)}(0,a(91179).D)([g,I,v,h]),(0,r.A)(g,"00fa0fe200fea1fd4091c604922a2f98c10ff5e691",null),(0,r.A)(I,"401eaa26aa87d9f036725b79c56518de68f8fdd77c",null),(0,r.A)(v,"009326ee3cf7182c7b6269fdbd06fae08f5a8be5b3",null),(0,r.A)(h,"4027ff2a9ba69ae80d05c70e793f141bd081ac43fb",null)},28533:(t,e,a)=>{a.d(e,{t:()=>r});class r extends Error{constructor(){super("Cart was not returned in response"),this.name="MissingCartError"}}},31176:(t,e,a)=>{a.d(e,{K:()=>r});let r=a(51094).z.string().length(3).toUpperCase().refine(t=>/^[A-Z]{3}$/.test(t),{message:"Must be a valid currency code"})},50551:(t,e,a)=>{a.d(e,{H:()=>o,l:()=>u});var r=a(10628),n=a(51094);let s=n.z.object({id:n.z.number(),message:n.z.string(),description:n.z.string().optional(),variant:n.z.enum(["success","error","warning","info"]),position:n.z.enum(["top-left","top-right","top-center","bottom-left","bottom-right","bottom-center"]).optional()}),i="toast-notification";async function c(t){(await (0,r.UL)()).set(i,btoa(JSON.stringify(t)),{httpOnly:!0,secure:!0,sameSite:"strict",path:"/",partitioned:!0,maxAge:0})}let o={success:async(t,e)=>{await c({id:Date.now(),message:t,variant:"success",...e})},error:async(t,e)=>{await c({id:Date.now(),message:t,variant:"error",...e})},warning:async(t,e)=>{await c({id:Date.now(),message:t,variant:"warning",...e})},info:async(t,e)=>{await c({id:Date.now(),message:t,variant:"info",...e})}},u=async()=>{let t=(await (0,r.UL)()).get(i);if(!t)return null;try{var e;return e=t.value,s.parse(JSON.parse(atob(e)))}catch(t){return console.error("Failed to decode toast notification cookie",t),null}}},72989:(t,e,a)=>{a.d(e,{g:()=>r});let r={cart:"cart",checkout:"checkout",customer:"customer"}}};