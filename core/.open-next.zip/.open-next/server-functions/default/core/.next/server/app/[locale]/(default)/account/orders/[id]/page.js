(()=>{var e={};e.id=6428,e.ids=[6428],e.modules={2265:(e,r,s)=>{"use strict";s.d(r,{E:()=>n});var a=s(11248),t=s(22584);function n({children:e,shape:r="rounded",className:s,variant:n="primary"}){return(0,a.jsx)("span",{className:(0,t.$)("px-2 py-0.5 font-[family-name:var(--badge-font-family,var(--font-family-mono))] text-xs uppercase tracking-tighter text-[var(--badge-text,hsl(var(--foreground)))]",{pill:"rounded-full",rounded:"rounded"}[r],{primary:"bg-[var(--badge-primary-background,color-mix(in_oklab,_hsl(var(--primary)),_white_75%))]",warning:"bg-[var(--badge-warning-background,color-mix(in_oklab,_hsl(var(--warning)),_white_75%))]",error:"bg-[var(--badge-error-background,color-mix(in_oklab,_hsl(var(--error)),_white_75%))]",success:"bg-[var(--badge-success-background,color-mix(in_oklab,_hsl(var(--success)),_white_75%))]",info:"bg-[var(--badge-info-background,color-mix(in_oklab,_hsl(var(--background)),_black_5%))]"}[n],s),children:e})}},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},6131:(e,r,s)=>{"use strict";s.r(r),s.d(r,{GlobalError:()=>i.a,__next_app__:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>d});var a=s(75448),t=s(25831),n=s(40440),i=s.n(n),l=s(53136),o={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>l[e]);s.d(r,o);let d={children:["",{children:["[locale]",{children:["(default)",{children:["account",{children:["orders",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,64897)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/orders/[id]/page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,12300)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/layout.tsx"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,92028)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/layout.tsx"],error:[()=>Promise.resolve().then(s.bind(s,67446)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/error.tsx"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,46774)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/layout.tsx"],error:[()=>Promise.resolve().then(s.bind(s,59599)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/error.tsx"],"not-found":[()=>Promise.resolve().then(s.bind(s,79037)),"/Users/jorge.moya/dev/catalyst/core/app/[locale]/not-found.tsx"]}]},{"not-found":[()=>Promise.resolve().then(s.t.bind(s,41933,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(s.t.bind(s,49520,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(s.t.bind(s,28129,23)),"next/dist/client/components/unauthorized-error"]}]}.children,c=["/Users/jorge.moya/dev/catalyst/core/app/[locale]/(default)/account/orders/[id]/page.tsx"],u={require:s,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:t.RouteKind.APP_PAGE,page:"/[locale]/(default)/account/orders/[id]/page",pathname:"/[locale]/account/orders/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},12300:(e,r,s)=>{"use strict";s.r(r),s.d(r,{default:()=>o});var a=s(11248),t=s(33043),n=s(27006),i=s(30042),l=s(86139);async function o({children:e,params:r}){let{locale:s}=await r;(0,t.I)(s);let o=await (0,n.A)("Account.Layout");return(0,a.jsx)(l.c,{sidebar:(0,a.jsx)(i.w,{links:[{href:"/account/orders/",label:o("orders")},{href:"/account/addresses/",label:o("addresses")},{href:"/account/settings/",label:o("settings")},{href:"/account/wishlists/",label:o("wishlists")},{href:"/logout",label:o("logout"),prefetch:"none"}]}),sidebarSize:"small",children:e})}},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29727:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page-experimental.runtime.prod.js")},31017:(e,r,s)=>{"use strict";s.d(r,{A:()=>o});var a=s(51633);let t=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((e,r,s)=>!!e&&""!==e.trim()&&s.indexOf(e)===r).join(" ").trim();var i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let l=(0,a.forwardRef)(({color:e="currentColor",size:r=24,strokeWidth:s=2,absoluteStrokeWidth:t,className:l="",children:o,iconNode:d,...c},u)=>(0,a.createElement)("svg",{ref:u,...i,width:r,height:r,stroke:e,strokeWidth:t?24*Number(s)/Number(r):s,className:n("lucide",l),...c},[...d.map(([e,r])=>(0,a.createElement)(e,r)),...Array.isArray(o)?o:[o]])),o=(e,r)=>{let s=(0,a.forwardRef)(({className:s,...i},o)=>(0,a.createElement)(l,{ref:o,iconNode:r,className:n(`lucide-${t(e)}`,s),...i}));return s.displayName=`${e}`,s}},33873:e=>{"use strict";e.exports=require("path")},33902:(e,r,s)=>{"use strict";s.d(r,{K:()=>a});let a=(0,s(14315).U)(`
  fragment OrderItemFragment on OrderPhysicalLineItem {
    entityId
    productEntityId
    brand
    name
    quantity
    baseCatalogProduct {
      path
    }
    image {
      url: urlTemplate(lossy: true)
      altText
    }
    subTotalListPrice {
      value
      currencyCode
    }
    catalogProductWithOptionSelections {
      prices {
        price {
          value
          currencyCode
        }
      }
    }
    productOptions {
      __typename
      name
      value
    }
  }
`)},38786:(e,r,s)=>{Promise.resolve().then(s.bind(s,42400)),Promise.resolve().then(s.bind(s,6820))},47949:(e,r,s)=>{Promise.resolve().then(s.bind(s,90065)),Promise.resolve().then(s.bind(s,64570))},55511:e=>{"use strict";e.exports=require("crypto")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64897:(e,r,s)=>{"use strict";s.r(r),s.d(r,{default:()=>Y});var a=s(11248),t=s(95931),n=s(33043),i=s(27006),l=s(32742),o=s(8310),d=s(88525),c=s(2265),u=s(65441),m=s(21345),h=s(90065),x=s(64570);function p({order:e,title:r,orderSummaryLabel:s="Order summary",shipmentAddressLabel:t,shipmentMethodLabel:n,summaryTotalLabel:i,prevHref:l="/orders"}){return(0,a.jsx)("div",{className:"font-[family-name:var(--order-details-section-font-family,var(--font-family-body))] text-[var(--order-details-text-primary,hsl(var(--foreground)))] @container",children:(0,a.jsx)(o.Z6,{fallback:(0,a.jsx)(C,{prevHref:l}),value:e,children:e=>(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("div",{className:"flex gap-4 border-b border-[var(--order-details-section-border,hsl(var(--contrast-100)))] pb-8",children:[""!==l&&(0,a.jsx)(u.v,{href:l,shape:"circle",size:"small",variant:"ghost",children:(0,a.jsx)(d.A,{})}),(0,a.jsxs)("div",{className:"space-y-1",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsx)("h1",{className:"font-[family-name:var(--order-details-section-title-font-family,var(--font-family-heading))] text-4xl",children:r??`Order #${e.id}`}),(0,a.jsx)(c.E,{variant:e.statusColor,children:e.status})]}),(0,a.jsx)("p",{className:"text-base font-light",children:e.date})]})]}),(0,a.jsxs)("div",{className:"grid @3xl:flex",children:[(0,a.jsx)("div",{className:"order-2 flex-1 pr-12 @3xl:order-1",children:e.destinations.map(e=>(0,a.jsx)(v,{addressLabel:t,destination:e,methodLabel:n},e.id))}),(0,a.jsxs)("div",{className:"order-1 basis-72 pt-8 @3xl:order-2",children:[(0,a.jsx)("div",{className:"font-[family-name:var(--order-details-section-title-font-family,var(--font-family-heading))] text-2xl font-medium",children:s}),(0,a.jsx)(j,{summary:e.summary,totalLabel:i})]})]})]})})})}function v({destination:e,addressLabel:r="Shipping address",methodLabel:s="Shipping method"}){return(0,a.jsx)("div",{className:"border-b border-[var(--order-details-section-border,hsl(var(--contrast-100)))] py-8 @container",children:(0,a.jsxs)("div",{className:"space-y-6",children:[(0,a.jsx)("div",{className:"font-[family-name:var(--order-details-section-title-font-family,var(--font-family-heading))] text-2xl font-medium",children:e.title}),(0,a.jsxs)("div",{className:"grid gap-8 @xl:flex @xl:gap-20",children:[(0,a.jsxs)("div",{className:"text-sm",children:[(0,a.jsx)("h3",{className:"font-semibold",children:r}),(0,a.jsxs)("div",{className:"text-[var(--order-details-text-secondary,hsl(var(--contrast-500)))]",children:[(0,a.jsx)("p",{children:e.address.name}),(0,a.jsx)("p",{children:e.address.street1}),(0,a.jsx)("p",{children:e.address.street2}),(0,a.jsx)("p",{children:`${e.address.city}, ${e.address.state} ${e.address.zipcode}`}),(0,a.jsx)("p",{children:e.address.country})]})]}),e.shipments.map((e,r)=>(0,a.jsxs)("div",{className:"text-sm",children:[(0,a.jsx)("h3",{className:"font-semibold",children:s}),(0,a.jsxs)("div",{className:"text-[var(--order-details-text-secondary,hsl(var(--contrast-500)))]",children:[(0,a.jsx)("p",{children:e.name}),(0,a.jsx)("p",{children:e.status}),(0,a.jsx)(b,{tracking:e.tracking})]})]},`${e.name}-${r}`))]}),e.lineItems.map(e=>(0,a.jsx)(g,{lineItem:e},e.id))]})})}function f({shipmentsPlaceholderCount:e=1,lineItemsPlaceholderCount:r=2}){return(0,a.jsx)("div",{className:"border-b border-[var(--order-details-section-border,hsl(var(--contrast-100)))] py-8 @container",children:(0,a.jsxs)("div",{className:"space-y-6",children:[(0,a.jsx)(m.EY,{characterCount:8,className:"rounded text-2xl"}),(0,a.jsxs)("div",{className:"grid gap-8 @xl:flex @xl:gap-20",children:[(0,a.jsxs)("div",{className:"text-sm",children:[(0,a.jsx)(m.EY,{characterCount:13,className:"rounded"}),(0,a.jsxs)("div",{children:[(0,a.jsx)(m.EY,{characterCount:8,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:12,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:16,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:8,className:"rounded"})]})]}),Array.from({length:e}).map((e,r)=>(0,a.jsxs)("div",{className:"text-sm",children:[(0,a.jsx)(m.EY,{characterCount:13,className:"rounded"}),(0,a.jsxs)("div",{children:[(0,a.jsx)(m.EY,{characterCount:16,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:8,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:24,className:"rounded"})]})]},r))]}),Array.from({length:r}).map((e,r)=>(0,a.jsx)(y,{},r))]})})}function b({tracking:e}){return e?"url"in e&&"number"in e?(0,a.jsx)("p",{children:(0,a.jsx)(x.Link,{href:e.url,target:"_blank",children:e.number})}):"url"in e?(0,a.jsx)("p",{children:(0,a.jsx)(x.Link,{href:e.url,target:"_blank",children:e.url})}):(0,a.jsx)("p",{children:e.number}):null}function g({lineItem:e}){return(0,a.jsxs)(({children:r})=>e.href?(0,a.jsx)(x.Link,{className:"group grid shrink-0 cursor-pointer gap-8 rounded-xl ring-[var(--order-details-section-focus,hsl(var(--primary)))] ring-offset-4 focus-visible:outline-none focus-visible:ring-2 @sm:flex @sm:rounded-2xl",href:e.href,id:e.id,children:r}):(0,a.jsx)("div",{className:"group grid shrink-0 gap-8 rounded-xl ring-[var(--order-details-section-focus,hsl(var(--primary)))] ring-offset-4 focus-visible:outline-none focus-visible:ring-2 @sm:flex @sm:rounded-2xl",id:e.id,children:r}),{children:[(0,a.jsx)("div",{className:"relative aspect-square basis-40 overflow-hidden rounded-[inherit] border border-[var(--order-details-section-border,hsl(var(--contrast-100)))] bg-[var(--order-details-section-image-background,hsl(var(--contrast-100)))]",children:e.image?.src!=null?(0,a.jsx)(h.Image,{alt:e.image.alt,className:"w-full scale-100 select-none object-cover transition-transform duration-500 ease-out group-hover:scale-110",fill:!0,sizes:"10rem",src:e.image.src}):(0,a.jsx)("div",{className:"pl-2 pt-3 text-4xl font-bold leading-[0.8] tracking-tighter text-[var(--order-details-section-line-item,hsl(var(--contrast-300)))] transition-transform duration-500 ease-out group-hover:scale-105",children:e.title})}),(0,a.jsxs)("div",{className:"space-y-3 text-sm leading-snug",children:[(0,a.jsxs)("div",{children:[(0,a.jsxs)("div",{className:"flex items-center gap-1 text-sm",children:[(0,a.jsx)("span",{className:"font-semibold",children:e.title}),(0,a.jsx)("span",{children:"\xd7"}),(0,a.jsx)("span",{className:"font-semibold",children:e.quantity})]}),null!=e.subtitle&&""!==e.subtitle&&(0,a.jsx)("div",{className:"font-normal text-[var(--order-details-section-line-item-subtitle,hsl(var(--contrast-500)))]",children:e.subtitle})]}),(0,a.jsxs)("div",{className:"flex gap-1 text-sm",children:[(0,a.jsx)("span",{className:"font-semibold",children:e.totalPrice}),e.quantity>1&&(0,a.jsxs)("span",{className:"font-normal",children:["(",e.price," each)"]})]}),(0,a.jsx)("div",{children:e.metadata?.map((e,r)=>(0,a.jsxs)("div",{className:"flex gap-1 text-sm",children:[(0,a.jsxs)("span",{className:"font-semibold",children:[e.label,":"]}),(0,a.jsx)("span",{children:e.value})]},`lineItem-meta-${e.label}-${r}`))})]})]})}function y(){return(0,a.jsxs)("div",{className:"group grid shrink-0 gap-8 rounded-xl @sm:flex @sm:rounded-2xl",children:[(0,a.jsx)("div",{className:"relative aspect-square basis-40 overflow-hidden rounded-[inherit]",children:(0,a.jsx)(m.az,{className:"h-full w-full"})}),(0,a.jsxs)("div",{className:"space-y-3 text-sm leading-snug",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:"flex items-center gap-1 text-sm",children:(0,a.jsx)(m.EY,{characterCount:24,className:"rounded"})}),(0,a.jsx)(m.EY,{characterCount:6,className:"rounded"})]}),(0,a.jsxs)("div",{className:"flex gap-1 text-sm",children:[(0,a.jsx)(m.EY,{characterCount:5,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:8,className:"rounded"})]}),(0,a.jsx)("div",{children:(0,a.jsxs)("div",{className:"flex gap-1 text-sm",children:[(0,a.jsx)(m.EY,{characterCount:7,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:3,className:"rounded"})]})})]})]})}function j({summary:e,totalLabel:r="Total"}){return(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:"space-y-2 pb-3 pt-5",children:e.lineItems.map((e,r)=>(0,a.jsxs)("div",{className:"flex justify-between",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:"text-sm",children:e.label}),null!=e.subtext&&""!==e.subtext&&(0,a.jsx)("div",{className:"text-xs text-[var(--order-details-section-line-item-subtext,hsl(var(--contrast-400)))]",children:e.subtext})]}),(0,a.jsx)("span",{className:"text-sm",children:e.value})]},r))}),(0,a.jsxs)("div",{className:"flex justify-between border-t border-[var(--order-details-section-border,hsl(var(--contrast-100)))] py-3 font-semibold",children:[(0,a.jsx)("span",{children:r}),(0,a.jsx)("span",{children:e.total})]})]})}function N({placeholderCount:e=2}){return(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:"space-y-2 pb-3 pt-5",children:Array.from({length:e}).map((e,r)=>(0,a.jsxs)("div",{className:"flex justify-between",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)(m.EY,{characterCount:6,className:"rounded text-sm"}),(0,a.jsx)(m.EY,{characterCount:12,className:"rounded text-xs"})]}),(0,a.jsx)(m.EY,{characterCount:6,className:"rounded text-sm"})]},r))}),(0,a.jsxs)("div",{className:"flex justify-between border-t border-[var(--order-details-section-border,hsl(var(--contrast-100)))] py-3",children:[(0,a.jsx)(m.EY,{characterCount:6,className:"rounded"}),(0,a.jsx)(m.EY,{characterCount:6,className:"rounded"})]})]})}function C({prevHref:e,placeholderCount:r=1,lineItemsPlaceholderCount:s=2}){return(0,a.jsxs)("div",{className:"animate-pulse",children:[(0,a.jsxs)("div",{className:"flex gap-4 border-b border-[var(--order-details-section-border,hsl(var(--contrast-100)))] pb-8",children:[null!=e&&""!==e&&(0,a.jsx)(u.v,{href:e,shape:"circle",size:"small",variant:"ghost",children:(0,a.jsx)(d.A,{})}),(0,a.jsxs)("div",{className:"space-y-1",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3",children:[(0,a.jsx)(m.EY,{characterCount:8,className:"rounded text-4xl"}),(0,a.jsx)(m.EY,{characterCount:8,className:"rounded text-xs"})]}),(0,a.jsx)(m.EY,{characterCount:7,className:"rounded text-base"})]})]}),(0,a.jsxs)("div",{className:"grid @3xl:flex",children:[(0,a.jsx)("div",{className:"order-2 flex-1 pr-12 @3xl:order-1",children:Array.from({length:r}).map((e,r)=>(0,a.jsx)(f,{lineItemsPlaceholderCount:s},r))}),(0,a.jsxs)("div",{className:"order-1 basis-72 pt-8 @3xl:order-2",children:[(0,a.jsx)(m.EY,{characterCount:10,className:"rounded text-2xl"}),(0,a.jsx)(N,{placeholderCount:3})]})]})]})}let A=(e,r,s)=>({date:s.dateTime(new Date(e.orderedAt.utc)),id:String(e.entityId),status:e.status.label,statusColor:function(e){switch(e){case"AWAITING_FULFILLMENT":case"AWAITING_SHIPMENT":case"AWAITING_PICKUP":case"PARTIALLY_SHIPPED":case"PENDING":case"SHIPPED":return"info";case"AWAITING_PAYMENT":case"DISPUTED":case"INCOMPLETE":case"MANUAL_VERIFICATION_REQUIRED":return"warning";case"CANCELLED":case"DECLINED":return"error";case"COMPLETED":case"PARTIALLY_REFUNDED":case"REFUNDED":return"success"}}(e.status.value),destinations:e.consignments.shipping?.map((e,a,t)=>({id:String(e.entityId),lineItems:e.lineItems.map(e=>{let r=e.catalogProductWithOptionSelections?.prices?.price?s.number(e.catalogProductWithOptionSelections.prices.price.value,{style:"currency",currency:e.catalogProductWithOptionSelections.prices.price.currencyCode}):s.number(e.subTotalListPrice.value/e.quantity,{style:"currency",currency:e.subTotalListPrice.currencyCode});return{id:String(e.entityId),title:e.name,subtitle:e.brand??"",price:r,totalPrice:s.number(e.subTotalListPrice.value,{style:"currency",currency:e.subTotalListPrice.currencyCode}),href:e.baseCatalogProduct?.path??void 0,image:e.image?{src:e.image.url,alt:e.image.altText}:void 0,quantity:e.quantity,metadata:e.productOptions.map(e=>({label:e.name,value:e.value}))}}),title:t.length>1?r("destinationWithCount",{number:a+1,total:t.length}):r("destination"),address:{city:e.shippingAddress.city??"",country:e.shippingAddress.country,state:e.shippingAddress.stateOrProvince??"",street1:e.shippingAddress.address1??"",street2:e.shippingAddress.address2??"",name:`${e.shippingAddress.firstName} ${e.shippingAddress.lastName}`,zipcode:e.shippingAddress.postalCode},shipments:e.shipments.map(e=>({name:e.shippingMethodName,status:s.dateTime(new Date(e.shippedAt.utc)),tracking:e.tracking??void 0}))}))??[],summary:{total:s.number(e.totalIncTax.value,{style:"currency",currency:e.totalIncTax.currencyCode}),lineItems:[{label:r("subtotal"),value:s.number(e.subTotal.value,{style:"currency",currency:e.subTotal.currencyCode})},...e.discounts.couponDiscounts.map(e=>({label:e.couponCode,value:`-${s.number(e.discountedAmount.value,{style:"currency",currency:e.discountedAmount.currencyCode})}`})),{label:r("shipping"),value:s.number(e.shippingCostTotal.value,{style:"currency",currency:e.shippingCostTotal.currencyCode})},{label:r("tax"),value:s.number(e.taxTotal.value,{style:"currency",currency:e.taxTotal.currencyCode})}]}});var k=s(31311),E=s(51633),P=s(13051),I=s(13832),_=s(14315),w=s(72989),T=s(33902);let L=(0,_.U)(`
    query CustomerOrderDetails($filter: OrderFilterInput) {
      site {
        order(filter: $filter) {
          entityId
          orderedAt {
            utc
          }
          status {
            label
            value
          }
          totalIncTax {
            value
            currencyCode
          }
          subTotal {
            value
            currencyCode
          }
          discounts {
            nonCouponDiscountTotal {
              value
              currencyCode
            }
            couponDiscounts {
              couponCode
              discountedAmount {
                value
                currencyCode
              }
            }
          }
          shippingCostTotal {
            value
            currencyCode
          }
          taxTotal {
            value
            currencyCode
          }
          billingAddress {
            firstName
            lastName
            address1
            city
            stateOrProvince
            postalCode
            country
          }
          consignments {
            shipping {
              edges {
                node {
                  entityId
                  shippingAddress {
                    firstName
                    lastName
                    address1
                    address2
                    city
                    stateOrProvince
                    postalCode
                    country
                  }
                  shipments {
                    edges {
                      node {
                        entityId
                        shippedAt {
                          utc
                        }
                        shippingMethodName
                        shippingProviderName
                        tracking {
                          __typename
                          ... on OrderShipmentNumberAndUrlTracking {
                            number
                            url
                          }
                          ... on OrderShipmentUrlOnlyTracking {
                            url
                          }
                          ... on OrderShipmentNumberOnlyTracking {
                            number
                          }
                        }
                      }
                    }
                  }
                  lineItems {
                    edges {
                      node {
                        ...OrderItemFragment
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  `,[T.K]),O=(0,E.cache)(async e=>{let r=await (0,P.GG)(),s=(await I.S.fetch({document:L,variables:{filter:{entityId:e}},fetchOptions:{cache:"no-store",next:{tags:[w.g.customer]}},customerAccessToken:r,errorPolicy:"auth"})).data.site.order;if(s)return{...s,consignments:{shipping:s.consignments?.shipping&&(0,k.removeEdgesAndNodes)(s.consignments.shipping).map(e=>({...e,lineItems:(0,k.removeEdgesAndNodes)(e.lineItems),shipments:(0,k.removeEdgesAndNodes)(e.shipments)}))}}});async function Y(e){let{id:r,locale:s}=await e.params;(0,n.I)(s);let d=await (0,i.A)("Account.Orders.Details"),c=await (0,l.A)(),u=o.RE.from(async()=>{let e=await O(Number(r));return e||(0,t.notFound)(),A(e,d,c)});return(0,a.jsx)(p,{order:u,orderSummaryLabel:d("orderSummary"),prevHref:"/account/orders",shipmentAddressLabel:d("shippingAddress"),shipmentMethodLabel:d("shippingMethod"),summaryTotalLabel:d("summaryTotal"),title:d("title",{orderNumber:r})})}},65441:(e,r,s)=>{"use strict";s.d(r,{v:()=>i});var a=s(11248),t=s(22584),n=s(64570);function i({variant:e="primary",size:r="large",shape:s="pill",className:i,children:l,...o}){return(0,a.jsx)(n.Link,{...o,className:(0,t.$)("relative z-0 inline-flex h-fit select-none items-center justify-center overflow-hidden border text-center font-[family-name:var(--button-font-family)] font-semibold leading-normal after:absolute after:inset-0 after:-z-10 after:-translate-x-[105%] after:transition-[opacity,transform] after:duration-300 after:[animation-timing-function:cubic-bezier(0,0.25,0,1)] hover:after:translate-x-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--button-focus,hsl(var(--primary)))] focus-visible:ring-offset-2",{primary:"border-[var(--button-primary-border,hsl(var(--primary)))] bg-[var(--button-primary-background,hsl(var(--primary)))] text-[var(--button-primary-text)] after:bg-[var(--button-primary-background-hover,color-mix(in_oklab,hsl(var(--primary)),white_75%))]",secondary:"border-[var(--button-secondary-border,hsl(var(--foreground)))] bg-[var(--button-secondary-background,hsl(var(--foreground)))] text-[var(--button-secondary-text,hsl(var(--background)))] after:bg-[var(--button-secondary-background-hover,hsl(var(--background)))]",tertiary:"border-[var(--button-tertiary-border,hsl(var(--contrast-200)))] bg-[var(--button-tertiary-background,hsl(var(--background)))] text-[var(--button-tertiary-text,hsl(var(--foreground)))] after:bg-[var(--button-tertiary-background-hover,hsl(var(--contrast-100)))]",ghost:"border-[var(--button-ghost-border,transparent)] bg-[var(--button-ghost-background,transparent)] text-[var(--button-ghost-text,hsl(var(--foreground)))] after:bg-[var(--button-ghost-background-hover,hsl(var(--foreground)/5%))]"}[e],{"x-small":"min-h-8 text-xs",small:"min-h-10 text-sm",medium:"min-h-12 text-base",large:"min-h-14 text-base"}[r],"circle"!==s&&({"x-small":"gap-x-2 px-3 py-1.5",small:"gap-x-2 px-4 py-2.5",medium:"gap-x-2.5 px-5 py-3",large:"gap-x-3 px-6 py-4"})[r],{pill:"rounded-full after:rounded-full",rounded:"rounded-lg after:rounded-lg",square:"rounded-none after:rounded-none",circle:"aspect-square rounded-full after:rounded-full"}[s],i),children:(0,a.jsx)("span",{className:(0,t.$)("secondary"===e&&"mix-blend-difference"),children:l})})}},77598:e=>{"use strict";e.exports=require("node:crypto")},88525:(e,r,s)=>{"use strict";s.d(r,{A:()=>a});let a=(0,s(31017).A)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},98438:(e,r,s)=>{"use strict";s.r(r),s.d(r,{"009326ee3cf7182c7b6269fdbd06fae08f5a8be5b3":()=>a.JQ,"00f18cd8f3edfe417e761e6c7a167eca95fbc78a82":()=>t._,"00fa0fe200fea1fd4091c604922a2f98c10ff5e691":()=>a.Cy,"401eaa26aa87d9f036725b79c56518de68f8fdd77c":()=>a.Om,"4027ff2a9ba69ae80d05c70e793f141bd081ac43fb":()=>a.IG,"40810c2ada176e44cfc36ac58dfc838c0fa8338e6c":()=>t.k,"605cffa0d02884f0c79832e05be84d44feb31db33a":()=>n.$,"7f08b5bad64ff7f096accb2dbd212712f01ebc5eea":()=>i.G,"7ffa7d8d01732763bccc5f6cf120234bca98d73077":()=>i.Z});var a=s(18657),t=s(5557),n=s(24986),i=s(81488)}};var r=require("../../../../../../webpack-runtime.js");r.C(e);var s=e=>r(r.s=e),a=r.X(0,[1407,8485,3615,2375,4269,6955,524,7559,295,5444,7708,6043,1931,9630,789],()=>s(6131));module.exports=a})();